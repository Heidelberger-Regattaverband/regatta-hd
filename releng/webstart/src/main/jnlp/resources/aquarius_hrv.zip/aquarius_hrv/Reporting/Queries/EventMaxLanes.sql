SELECT
	ISNULL(MAX(RaceMode_LaneCount), 0) AS 'LaneCount'
FROM
	RaceMode
	JOIN Offer ON Offer_RaceMode_ID_FK = RaceMode_ID
WHERE
	Offer_Event_ID_FK = %event%