CREATE TABLE ProgressionRule
(
	PR_ID INT IDENTITY(1,1) NOT NULL,
	PR_RMLap_ID_FK INT NOT NULL
		CONSTRAINT FK_ProgressionRule_DstLap
		REFERENCES RaceMode_Detail (RMLap_ID)
		ON UPDATE CASCADE
		ON DELETE CASCADE,
	PR_Src_Lap_ID_FK INT NULL
		--- no action here, there may be no source lap (e.g. random choice rules)
		CONSTRAINT FK_ProgressionRule_SrcLap
		REFERENCES RaceMode_Detail (RMLap_ID),
	PR_Order SMALLINT NOT NULL CONSTRAINT [DF_PG_Order]  DEFAULT ((0)),
	PR_Type CHAR(1) NOT NULL CONSTRAINT [DF_PG_Type]  DEFAULT ('R'),
	PR_Arg TINYINT NULL,
	PR_Option TINYINT NULL,
	CONSTRAINT PK_ProgressionRule PRIMARY KEY CLUSTERED
	(
		PR_ID ASC
	)
)
