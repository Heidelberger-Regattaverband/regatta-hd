SELECT DISTINCT
	Athlet_ID,
	Athlet_LastName,
	Athlet_FirstName,
	Athlet_Gender,
	YEAR(Athlet_DOB) AS Athlet_YOB,
	Athlet_Club_ID_FK,
	Athlet_ExternID_A,
	Athlet_State,
	Athlet_ExternState,
	Athlet_ExternState_B,
	Club_UltraAbbr,
	Crew_Club_ID_FK,
	Nation_IOC_Code
FROM
	Crew
	LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	LEFT JOIN Event ON Entry_Event_ID_FK = Event_ID
	LEFT JOIN Athlet ON Crew_Athlete_ID_FK = Athlet_ID
	LEFT JOIN Club ON Club_ID = Crew_Club_ID_FK
	LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
WHERE
	Event_ID = %event%
ORDER BY
	Athlet_LastName,
	Athlet_FirstName
