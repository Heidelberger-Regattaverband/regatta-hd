-- update logos path to be relative to 'images' directory (not reporting root dir)
DECLARE @@pattern AS VARCHAR(16) = 'images\'
UPDATE Event SET Event_HeadLogo_A = SUBSTRING(Event_HeadLogo_A, LEN(@@pattern) + 1, LEN(Event_HeadLogo_A)) WHERE LEFT(Event_HeadLogo_A, LEN(@@pattern)) = @@pattern
UPDATE Event SET Event_HeadLogo_B = SUBSTRING(Event_HeadLogo_B, LEN(@@pattern) + 1, LEN(Event_HeadLogo_B)) WHERE LEFT(Event_HeadLogo_B, LEN(@@pattern)) = @@pattern
UPDATE Event SET Event_FootLogo = SUBSTRING(Event_FootLogo, LEN(@@pattern) + 1, LEN(Event_FootLogo)) WHERE LEFT(Event_FootLogo, LEN(@@pattern)) = @@pattern