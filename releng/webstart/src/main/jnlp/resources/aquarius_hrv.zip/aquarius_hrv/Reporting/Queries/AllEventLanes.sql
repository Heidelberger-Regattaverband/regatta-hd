SELECT
	CE_ID,
	CE_Entry_ID_FK,
	CE_Comp_ID_FK,
	CE_Lane
FROM
	CompEntries
	LEFT JOIN Comp ON CE_Comp_ID_FK = Comp_ID
	LEFT JOIN Offer ON Comp_Race_ID_FK = Offer_ID
WHERE
	Offer_Event_ID_FK = %event%
ORDER BY
	Offer_ID,
	Comp_ID,
	CE_Lane