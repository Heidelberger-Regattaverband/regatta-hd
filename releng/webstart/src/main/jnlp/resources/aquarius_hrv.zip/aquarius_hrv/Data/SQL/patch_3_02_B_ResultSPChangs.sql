CREATE PROCEDURE CreateResult
    @CompEntryID_FK INT,
    @Split TINYINT
AS 
BEGIN
    SET NOCOUNT ON;
-- check if result exists
    SELECT 
        Result_CE_ID_FK
    FROM
        Result
    WHERE 
        Result_CE_ID_FK = @CompEntryID_FK
        AND Result_SplitNr = @Split
        
-- insert new result with preliminary values 
-- THINK: ResultType and DisplayType might be NULL in future versions
    IF (@@ROWCOUNT = 0 )
    BEGIN
        INSERT INTO 
            Result(Result_CE_ID_FK, Result_SplitNr, Result_ResultType, Result_DisplayType)
        VALUES 
            (@CompEntryID_FK, @Split, 'X', 'X')
    END
END