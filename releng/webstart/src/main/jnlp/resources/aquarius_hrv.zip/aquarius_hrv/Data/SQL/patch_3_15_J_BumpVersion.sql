--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.15'
WHERE
	MetaData_Key = 'PatchLevel'