--- increase patch level
--- version 3.10 does not change the db structure but enforces
--- the update of umpiring data (which is not included in VCS)
UPDATE
	MetaData
SET
	MetaData_Value = '3.10'
WHERE
	MetaData_Key = 'PatchLevel'
