ALTER TABLE RaceMode ADD RaceMode_LaneCount SMALLINT NOT NULL DEFAULT(1)
GO

UPDATE RaceMode SET RaceMode_LaneCount = 3 WHERE RaceMode_Title LIKE '%3 Bahnen%'
UPDATE RaceMode SET RaceMode_LaneCount = 4 WHERE RaceMode_Title LIKE '%4 Bahnen%'
UPDATE RaceMode SET RaceMode_LaneCount = 5 WHERE RaceMode_Title LIKE '%5 Bahnen%'
UPDATE RaceMode SET RaceMode_LaneCount = 6 WHERE RaceMode_Title LIKE '%6 Bahnen%'
UPDATE RaceMode SET RaceMode_LaneCount = 7 WHERE RaceMode_Title LIKE '%7 Bahnen%'
UPDATE RaceMode SET RaceMode_LaneCount = 8 WHERE RaceMode_Title LIKE '%8 Bahnen%'