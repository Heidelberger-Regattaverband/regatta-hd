-- this is a use-once update for the umpire data that was included
-- in the initialy delivered database. This update refreshes licence
-- numbers and adds new umpires who acquired licences in the meantime
-- NOTE: this update will be removed with the second next major update
-- in order to remove the data-sensitve stuff from the download

-- clean umpire names
UPDATE
	Referee
SET
	Referee_FirstName = LTRIM(RTRIM(Referee_FirstName)),
	Referee_LastName = LTRIM(RTRIM(Referee_LastName)),
	Referee_City = LTRIM(RTRIM(Referee_City))

-- update umpire data
UPDATE
	Referee
SET
	Referee_LicenceState = 0
WHERE
	(Referee_LastName = 'Beck' AND Referee_FirstName = 'Frank') OR
	(Referee_LastName = 'Becker' AND Referee_FirstName = 'Manfred') OR
	(Referee_LastName = 'Bergmann' AND Referee_FirstName = 'Werner') OR
	(Referee_LastName = 'Blasberg' AND Referee_FirstName = 'Gunter') OR
	(Referee_LastName = 'Blumberg' AND Referee_FirstName = 'Thomas') OR
	(Referee_LastName = 'Bock' AND Referee_FirstName = 'Gerd') OR
	(Referee_LastName = 'Borges' AND Referee_FirstName = 'Jutta') OR
	(Referee_LastName = 'Breidenbach' AND Referee_FirstName = 'Georg') OR
	(Referee_LastName = 'Breitenbach' AND Referee_FirstName = 'Thomas') OR
	(Referee_LastName = 'B�hm' AND Referee_FirstName = 'Horst-Elmar') OR
	(Referee_LastName = 'Duif' AND Referee_FirstName = 'Hartmut') OR
	(Referee_LastName = 'Finkenbusch' AND Referee_FirstName = 'Vera') OR
	(Referee_LastName = 'Fritsche' AND Referee_FirstName = 'Marcel Christian') OR
	(Referee_LastName = 'Gleim' AND Referee_FirstName = 'Lukas') OR
	(Referee_LastName = 'Grau' AND Referee_FirstName = 'Philipp') OR
	(Referee_LastName = 'Gregor' AND Referee_FirstName = 'Undine') OR
	(Referee_LastName = 'Greve' AND Referee_FirstName = 'Rolf') OR
	(Referee_LastName = 'Heyn' AND Referee_FirstName = 'Michael') OR
	(Referee_LastName = 'Hilbig' AND Referee_FirstName = 'Karl-Heinz') OR
	(Referee_LastName = 'Hofmann' AND Referee_FirstName = 'Frank') OR
	(Referee_LastName = 'Hucke' AND Referee_FirstName = 'Dirk') OR
	(Referee_LastName = 'J�rger' AND Referee_FirstName = 'Katrin') OR
	(Referee_LastName = 'Kahler' AND Referee_FirstName = 'Peter') OR
	(Referee_LastName = 'Kaidel' AND Referee_FirstName = 'Siegfried') OR
	(Referee_LastName = 'Knespel' AND Referee_FirstName = 'Michael') OR
	(Referee_LastName = 'Kramp' AND Referee_FirstName = 'Hans-J�rgen') OR
	(Referee_LastName = 'Landmann' AND Referee_FirstName = 'Alina Johanna') OR
	(Referee_LastName = 'Lechtenb�hmer' AND Referee_FirstName = 'Andrea') OR
	(Referee_LastName = 'Lembke' AND Referee_FirstName = 'Klaus-Dieter') OR
	(Referee_LastName = 'Loest' AND Referee_FirstName = 'Wolfgang') OR
	(Referee_LastName = 'Lubenow' AND Referee_FirstName = 'Imke') OR
	(Referee_LastName = 'L�ffler' AND Referee_FirstName = 'Rudolf-Hans') OR
	(Referee_LastName = 'Malek' AND Referee_FirstName = 'Sebastian') OR
	(Referee_LastName = 'Matzner' AND Referee_FirstName = 'Manfred') OR
	(Referee_LastName = 'Nie�mann' AND Referee_FirstName = 'Wolfgang') OR
	(Referee_LastName = 'Pies' AND Referee_FirstName = 'Klaus') OR
	(Referee_LastName = 'Rehbein' AND Referee_FirstName = 'Hans-Thomas') OR
	(Referee_LastName = 'Richter' AND Referee_FirstName = 'Danny') OR
	(Referee_LastName = 'Richter' AND Referee_FirstName = 'Ramona') OR
	(Referee_LastName = 'Rohr' AND Referee_FirstName = 'Holger') OR
	(Referee_LastName = 'Rosenberg' AND Referee_FirstName = 'Ulrich') OR
	(Referee_LastName = 'R�mmling' AND Referee_FirstName = 'Catrin') OR
	(Referee_LastName = 'Sauter' AND Referee_FirstName = 'Lothar') OR
	(Referee_LastName = 'Schaefer' AND Referee_FirstName = 'Ulf') OR
	(Referee_LastName = 'Scheve' AND Referee_FirstName = 'Peter') OR
	(Referee_LastName = 'Schintze' AND Referee_FirstName = 'Reinhard') OR
	(Referee_LastName = 'Scholler' AND Referee_FirstName = 'Peter') OR
	(Referee_LastName = 'Schreiber' AND Referee_FirstName = 'Heidrun') OR
	(Referee_LastName = 'Schr�der' AND Referee_FirstName = 'Kai Jan') OR
	(Referee_LastName = 'Schr�ter' AND Referee_FirstName = 'Stefan') OR
	(Referee_LastName = 'Schulz' AND Referee_FirstName = 'Eckhard') OR
--	(Referee_LastName = 'Sch�tzel' AND Referee_FirstName = 'Manfred') OR
	(Referee_LastName = 'Sonntag' AND Referee_FirstName = 'Beate') OR
	(Referee_LastName = 'Stahnke' AND Referee_FirstName = 'Wolfgang') OR
	(Referee_LastName = 'Straube' AND Referee_FirstName = 'Karl') OR
	(Referee_LastName = 'Szillat' AND Referee_FirstName = 'Lutz') OR
--	(Referee_LastName = 'Vogel' AND Referee_FirstName = 'Helmut') OR
	(Referee_LastName = 'Westemeyer' AND Referee_FirstName = 'Anita Stephanie') OR
	(Referee_LastName = 'Widmann' AND Referee_FirstName = 'Markus') OR
	(Referee_LastName = 'Wittenberg' AND Referee_FirstName = 'Berend')

IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ackermann' AND Referee_FirstName = 'Jan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ackermann', 'Jan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ahrens' AND Referee_FirstName = 'Hendrik') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ahrens', 'Hendrik') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Aits' AND Referee_FirstName = 'Wilm') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Aits', 'Wilm') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Alpen' AND Referee_FirstName = 'Bert') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Alpen', 'Bert') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Arens' AND Referee_FirstName = 'Bastian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Arens', 'Bastian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Bauder' AND Referee_FirstName = 'Kurt') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Bauder', 'Kurt') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Beissel' AND Referee_FirstName = 'Theresa') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Beissel', 'Theresa') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Benthaus' AND Referee_FirstName = 'Vera') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Benthaus', 'Vera') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Berger' AND Referee_FirstName = 'Stephan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Berger', 'Stephan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Beutler' AND Referee_FirstName = 'Werner') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Beutler', 'Werner') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Biel' AND Referee_FirstName = 'Alexander') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Biel', 'Alexander') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Bitsch' AND Referee_FirstName = 'Karl') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Bitsch', 'Karl') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Bitter' AND Referee_FirstName = 'Mark') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Bitter', 'Mark') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Boes' AND Referee_FirstName = 'Arno') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Boes', 'Arno') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Bogenrieder' AND Referee_FirstName = 'J�rgen') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Bogenrieder', 'J�rgen') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Bohling' AND Referee_FirstName = 'Lars') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Bohling', 'Lars') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Botzum' AND Referee_FirstName = 'Jens') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Botzum', 'Jens') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Brandt' AND Referee_FirstName = 'Joachim') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Brandt', 'Joachim') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Brandt' AND Referee_FirstName = 'Peggy') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Brandt', 'Peggy') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Breitenbach' AND Referee_FirstName = 'Johannes') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Breitenbach', 'Johannes') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Brinck' AND Referee_FirstName = 'Dagmar') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Brinck', 'Dagmar') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Brinkhoff' AND Referee_FirstName = 'Marc') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Brinkhoff', 'Marc') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Bruch' AND Referee_FirstName = 'Susanne') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Bruch', 'Susanne') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Brym' AND Referee_FirstName = 'Daniel') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Brym', 'Daniel') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Br�he' AND Referee_FirstName = 'Beate') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Br�he', 'Beate') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Buschmann' AND Referee_FirstName = 'Steffen') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Buschmann', 'Steffen') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Buschmann' AND Referee_FirstName = 'Heiner') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Buschmann', 'Heiner') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'B�umer' AND Referee_FirstName = 'Gerrit') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('B�umer', 'Gerrit') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'B�hning' AND Referee_FirstName = 'Carsten') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('B�hning', 'Carsten') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Damm' AND Referee_FirstName = 'Manuela') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Damm', 'Manuela') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Danzglock' AND Referee_FirstName = 'Dag') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Danzglock', 'Dag') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ebisch' AND Referee_FirstName = 'Laura') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ebisch', 'Laura') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Eichelhard' AND Referee_FirstName = 'Kerstin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Eichelhard', 'Kerstin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Eimers' AND Referee_FirstName = 'Axel') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Eimers', 'Axel') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Engel' AND Referee_FirstName = 'Steffi') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Engel', 'Steffi') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Engelmann' AND Referee_FirstName = 'Erhard') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Engelmann', 'Erhard') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Erche' AND Referee_FirstName = 'Ilja') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Erche', 'Ilja') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Faiss' AND Referee_FirstName = 'Christina') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Faiss', 'Christina') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Fenske' AND Referee_FirstName = 'Manuel') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Fenske', 'Manuel') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Fischer' AND Referee_FirstName = 'Klaus') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Fischer', 'Klaus') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Fleckenstein' AND Referee_FirstName = 'Claudia') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Fleckenstein', 'Claudia') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Franz' AND Referee_FirstName = 'Petra') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Franz', 'Petra') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Fricke' AND Referee_FirstName = 'Timm') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Fricke', 'Timm') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Frings' AND Referee_FirstName = 'Felix') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Frings', 'Felix') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Fr�hlich' AND Referee_FirstName = 'Holger') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Fr�hlich', 'Holger') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Fuchs' AND Referee_FirstName = 'Thorsten') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Fuchs', 'Thorsten') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Garmatter' AND Referee_FirstName = 'Volker') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Garmatter', 'Volker') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gerhart' AND Referee_FirstName = 'Anja') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gerhart', 'Anja') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gerking' AND Referee_FirstName = 'Klaus') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gerking', 'Klaus') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gerlang' AND Referee_FirstName = 'Petra') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gerlang', 'Petra') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gerstenmaier' AND Referee_FirstName = 'Uwe') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gerstenmaier', 'Uwe') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Goer' AND Referee_FirstName = 'Martin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Goer', 'Martin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Goldberg' AND Referee_FirstName = 'Holger') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Goldberg', 'Holger') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gorski' AND Referee_FirstName = 'Torsten') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gorski', 'Torsten') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gramann' AND Referee_FirstName = 'Anita') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gramann', 'Anita') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gravert' AND Referee_FirstName = 'Klaus') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gravert', 'Klaus') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Greiner' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Greiner', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gr�tzner' AND Referee_FirstName = 'Georg') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gr�tzner', 'Georg') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Gutsche' AND Referee_FirstName = 'Peter') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Gutsche', 'Peter') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'G�nter' AND Referee_FirstName = 'Henner') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('G�nter', 'Henner') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Habicht' AND Referee_FirstName = 'Sofia') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Habicht', 'Sofia') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Halama' AND Referee_FirstName = 'Peter') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Halama', 'Peter') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hamdorf' AND Referee_FirstName = 'Svenja') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hamdorf', 'Svenja') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hanfler' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hanfler', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hartmann' AND Referee_FirstName = 'Ulrike') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hartmann', 'Ulrike') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Haux' AND Referee_FirstName = 'Sebastian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Haux', 'Sebastian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Heinig' AND Referee_FirstName = 'Marie') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Heinig', 'Marie') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Heitsch' AND Referee_FirstName = 'Holger') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Heitsch', 'Holger') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Heitsch' AND Referee_FirstName = 'Torsten') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Heitsch', 'Torsten') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Helzel' AND Referee_FirstName = 'Astrid') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Helzel', 'Astrid') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Henne' AND Referee_FirstName = 'Mayk') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Henne', 'Mayk') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hesse' AND Referee_FirstName = 'Stefan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hesse', 'Stefan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hesselmann' AND Referee_FirstName = 'Lucas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hesselmann', 'Lucas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hildebrand' AND Referee_FirstName = 'Elke') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hildebrand', 'Elke') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hillen' AND Referee_FirstName = 'J�rgen') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hillen', 'J�rgen') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hintze' AND Referee_FirstName = 'Christian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hintze', 'Christian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Ron') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hoffmann', 'Ron') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Caroline') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hoffmann', 'Caroline') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Holger') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hoffmann', 'Holger') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Martin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Hoffmann', 'Martin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ingenh�tt' AND Referee_FirstName = 'J�rg') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ingenh�tt', 'J�rg') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Jacobs' AND Referee_FirstName = 'Wolfdietrich') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Jacobs', 'Wolfdietrich') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Jaeger' AND Referee_FirstName = 'Martin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Jaeger', 'Martin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Jautzke' AND Referee_FirstName = 'Deborah') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Jautzke', 'Deborah') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Jendro�ek' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Jendro�ek', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'J�ckel' AND Referee_FirstName = 'Christian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('J�ckel', 'Christian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kaeswurm' AND Referee_FirstName = 'Ulrich') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kaeswurm', 'Ulrich') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kaiser' AND Referee_FirstName = 'Jakob') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kaiser', 'Jakob') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kapeller' AND Referee_FirstName = 'Stefan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kapeller', 'Stefan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kassler' AND Referee_FirstName = 'Susanne') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kassler', 'Susanne') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Keschka' AND Referee_FirstName = 'Michael') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Keschka', 'Michael') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kienzle-Augspurger' AND Referee_FirstName = 'Monika') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kienzle-Augspurger', 'Monika') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kie�ler' AND Referee_FirstName = 'Stefan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kie�ler', 'Stefan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kilian' AND Referee_FirstName = 'Frank') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kilian', 'Frank') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Klauke' AND Referee_FirstName = 'Martin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Klauke', 'Martin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kleinfeldt' AND Referee_FirstName = 'Rainer') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kleinfeldt', 'Rainer') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kollnig' AND Referee_FirstName = 'Christof') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kollnig', 'Christof') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Korgitzsch' AND Referee_FirstName = 'Frank-Michael') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Korgitzsch', 'Frank-Michael') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Krajewski' AND Referee_FirstName = 'Stephan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Krajewski', 'Stephan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kramp' AND Referee_FirstName = 'Hans-Juergen') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kramp', 'Hans-Juergen') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Krehl' AND Referee_FirstName = 'Martina') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Krehl', 'Martina') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kreie' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kreie', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kretschmer' AND Referee_FirstName = 'Tobias') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kretschmer', 'Tobias') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kr�mer' AND Referee_FirstName = 'Sebastian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kr�mer', 'Sebastian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kuhnert' AND Referee_FirstName = 'Roman') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kuhnert', 'Roman') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Kumm-Kottke' AND Referee_FirstName = 'Sibylle') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Kumm-Kottke', 'Sibylle') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'K�nig' AND Referee_FirstName = 'Klaus-Dieter') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('K�nig', 'Klaus-Dieter') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'K�rner' AND Referee_FirstName = 'Annegret') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('K�rner', 'Annegret') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Langusch' AND Referee_FirstName = 'Dietmar') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Langusch', 'Dietmar') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Laube' AND Referee_FirstName = 'Tim') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Laube', 'Tim') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Laugwitz' AND Referee_FirstName = 'Eva') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Laugwitz', 'Eva') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Lechtenboehmer' AND Referee_FirstName = 'Andrea') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Lechtenboehmer', 'Andrea') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Lehne' AND Referee_FirstName = 'Frank') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Lehne', 'Frank') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Leube' AND Referee_FirstName = 'Thea') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Leube', 'Thea') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ludwig' AND Referee_FirstName = 'Steffen') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ludwig', 'Steffen') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Lupke' AND Referee_FirstName = 'Henriette') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Lupke', 'Henriette') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'L�ffler' AND Referee_FirstName = 'Rudolf') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('L�ffler', 'Rudolf') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Malota' AND Referee_FirstName = 'Myriam') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Malota', 'Myriam') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Mannheim' AND Referee_FirstName = 'Lothar') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Mannheim', 'Lothar') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Mayer' AND Referee_FirstName = 'Karin-Anne') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Mayer', 'Karin-Anne') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Menold' AND Referee_FirstName = 'Klaus') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Menold', 'Klaus') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Menold' AND Referee_FirstName = 'Petra') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Menold', 'Petra') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Mensch' AND Referee_FirstName = 'Martin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Mensch', 'Martin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Merz' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Merz', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Meyboden' AND Referee_FirstName = 'Gerhard') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Meyboden', 'Gerhard') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Meyer' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Meyer', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Meyer' AND Referee_FirstName = 'Sebastian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Meyer', 'Sebastian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Mieth' AND Referee_FirstName = 'Stefan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Mieth', 'Stefan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Molkenthin' AND Referee_FirstName = 'Karen') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Molkenthin', 'Karen') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Nehls' AND Referee_FirstName = 'S�nke') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Nehls', 'S�nke') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Niederreuther' AND Referee_FirstName = 'Ralf') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Niederreuther', 'Ralf') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Nikolai' AND Referee_FirstName = 'Joachim') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Nikolai', 'Joachim') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ocker' AND Referee_FirstName = 'B�rbel') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ocker', 'B�rbel') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ocker' AND Referee_FirstName = 'Burkhard') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ocker', 'Burkhard') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Oelze' AND Referee_FirstName = 'Christian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Oelze', 'Christian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Palfner' AND Referee_FirstName = 'Stefanie') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Palfner', 'Stefanie') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Pankatz' AND Referee_FirstName = 'Daniel') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Pankatz', 'Daniel') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Poppitz' AND Referee_FirstName = 'Dirk') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Poppitz', 'Dirk') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Prohn' AND Referee_FirstName = 'Malte') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Prohn', 'Malte') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Radke' AND Referee_FirstName = 'Heiko') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Radke', 'Heiko') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Rauhut' AND Referee_FirstName = 'Roland') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Rauhut', 'Roland') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ravens-Taeuber' AND Referee_FirstName = 'Gisela') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ravens-Taeuber', 'Gisela') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Ravens' AND Referee_FirstName = 'Bernd') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Ravens', 'Bernd') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Reppe' AND Referee_FirstName = 'Frank') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Reppe', 'Frank') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Reuschling' AND Referee_FirstName = 'Dirk') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Reuschling', 'Dirk') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Risse' AND Referee_FirstName = 'Anja') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Risse', 'Anja') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Rosemann' AND Referee_FirstName = 'Michael') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Rosemann', 'Michael') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Rupieper' AND Referee_FirstName = 'Svenja') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Rupieper', 'Svenja') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'R�mer' AND Referee_FirstName = 'Holger') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('R�mer', 'Holger') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'R�del' AND Referee_FirstName = 'Paloma') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('R�del', 'Paloma') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'R�del' AND Referee_FirstName = 'Willi') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('R�del', 'Willi') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Scharnagl' AND Referee_FirstName = 'Peter') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Scharnagl', 'Peter') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schauenburg' AND Referee_FirstName = 'Maik') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schauenburg', 'Maik') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schellenberg' AND Referee_FirstName = 'Frank') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schellenberg', 'Frank') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schenk' AND Referee_FirstName = 'Tilman') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schenk', 'Tilman') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schiek' AND Referee_FirstName = 'Doris') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schiek', 'Doris') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schirmer' AND Referee_FirstName = 'Oliver') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schirmer', 'Oliver') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schmidt' AND Referee_FirstName = 'Martin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schmidt', 'Martin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schmitz' AND Referee_FirstName = 'Lennert') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schmitz', 'Lennert') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schmolling' AND Referee_FirstName = 'Philip') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schmolling', 'Philip') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Scholler' AND Referee_FirstName = 'Axel') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Scholler', 'Axel') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schreiber' AND Referee_FirstName = 'Roland') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schreiber', 'Roland') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schroeter' AND Referee_FirstName = 'Stefan') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schroeter', 'Stefan') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schulz' AND Referee_FirstName = 'Tobias') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schulz', 'Tobias') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schumacher' AND Referee_FirstName = 'Valentin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schumacher', 'Valentin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Sch�tzel' AND Referee_FirstName = 'Manfred') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Sch�tzel', 'Manfred') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Schyr' AND Referee_FirstName = 'Christian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Schyr', 'Christian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Seeler' AND Referee_FirstName = 'Ricarda') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Seeler', 'Ricarda') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Seiffert' AND Referee_FirstName = 'Lena') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Seiffert', 'Lena') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Siegler' AND Referee_FirstName = 'Holger') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Siegler', 'Holger') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Sparmann' AND Referee_FirstName = 'Jens') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Sparmann', 'Jens') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Spingat' AND Referee_FirstName = 'Frank') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Spingat', 'Frank') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Stadler' AND Referee_FirstName = 'Sophie') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Stadler', 'Sophie') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Stephan' AND Referee_FirstName = 'Karin') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Stephan', 'Karin') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Straube' AND Referee_FirstName = 'Klaus') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Straube', 'Klaus') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Streckert' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Streckert', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Str�ttchen' AND Referee_FirstName = 'Andre') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Str�ttchen', 'Andre') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Terborg' AND Referee_FirstName = 'Oliver') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Terborg', 'Oliver') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Tietgen' AND Referee_FirstName = 'Tobias') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Tietgen', 'Tobias') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Tie�ler' AND Referee_FirstName = 'Michaela') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Tie�ler', 'Michaela') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Vercek' AND Referee_FirstName = 'Torsten') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Vercek', 'Torsten') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Vogel' AND Referee_FirstName = 'Helmut') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Vogel', 'Helmut') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Walter' AND Referee_FirstName = 'Gerhard') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Walter', 'Gerhard') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Warnke' AND Referee_FirstName = 'Nils') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Warnke', 'Nils') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Warnke' AND Referee_FirstName = 'Rolf') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Warnke', 'Rolf') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wei�' AND Referee_FirstName = 'Bj�rn') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wei�', 'Bj�rn') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wei�enberger' AND Referee_FirstName = 'Charlotte') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wei�enberger', 'Charlotte') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Westermann' AND Referee_FirstName = 'Tobias') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Westermann', 'Tobias') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Weysters' AND Referee_FirstName = 'Tobias') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Weysters', 'Tobias') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wiesner' AND Referee_FirstName = 'Jens') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wiesner', 'Jens') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wilz' AND Referee_FirstName = 'Volker') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wilz', 'Volker') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wilz' AND Referee_FirstName = 'R�diger') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wilz', 'R�diger') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Winter' AND Referee_FirstName = 'Manfred') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Winter', 'Manfred') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Witt' AND Referee_FirstName = 'Thomas') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Witt', 'Thomas') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wujanz' AND Referee_FirstName = 'Harald') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wujanz', 'Harald') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wulf' AND Referee_FirstName = 'Dennis') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wulf', 'Dennis') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Wuwer' AND Referee_FirstName = 'Sven') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Wuwer', 'Sven') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'W�stemeyer' AND Referee_FirstName = 'Eva') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('W�stemeyer', 'Eva') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Zillmann' AND Referee_FirstName = 'Fabian') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Zillmann', 'Fabian') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Z�ger' AND Referee_FirstName = 'Andrea') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Z�ger', 'Andrea') END
IF NOT EXISTS (SELECT Referee_ID FROM Referee WHERE Referee_LastName = 'Z�llner' AND Referee_FirstName = 'Volker') BEGIN INSERT INTO Referee (Referee_LastName, Referee_FirstName) VALUES ('Z�llner', 'Volker') END

-----------------------------------------------------------------------

DECLARE @Nat_ID_GER AS INT = (SELECT TOP 1 Nation.Nation_ID FROM Nation WHERE Nation_IOC_Code = 'GER')

UPDATE Referee SET Referee_ExternID = 897, Referee_City = 'D�sseldorf', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ackermann' AND Referee_FirstName = 'Jan'
UPDATE Referee SET Referee_ExternID = 2009111501, Referee_City = 'Backnang', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ahrens' AND Referee_FirstName = 'Hendrik'
UPDATE Referee SET Referee_ExternID = 787, Referee_City = 'Leer', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Aits' AND Referee_FirstName = 'Wilm'
UPDATE Referee SET Referee_ExternID = 815, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Alpen' AND Referee_FirstName = 'Bert'
UPDATE Referee SET Referee_ExternID = 2011022601, Referee_City = 'K�ln', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Arens' AND Referee_FirstName = 'Bastian'
UPDATE Referee SET Referee_ExternID = 790, Referee_City = 'Mannheim', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Bauder' AND Referee_FirstName = 'Kurt'
UPDATE Referee SET Referee_ExternID = 900, Referee_City = 'Dransfeld', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Beissel' AND Referee_FirstName = 'Theresa'
UPDATE Referee SET Referee_ExternID = 863, Referee_City = 'Waltrop', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Benthaus' AND Referee_FirstName = 'Vera'
UPDATE Referee SET Referee_ExternID = 898, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Berger' AND Referee_FirstName = 'Stephan'
UPDATE Referee SET Referee_ExternID = 636, Referee_City = 'Cuxhaven', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Beutler' AND Referee_FirstName = 'Werner'
UPDATE Referee SET Referee_ExternID = 894, Referee_City = 'Stuttgart', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Biel' AND Referee_FirstName = 'Alexander'
UPDATE Referee SET Referee_ExternID = 597, Referee_City = 'Breisach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Bitsch' AND Referee_FirstName = 'Karl'
UPDATE Referee SET Referee_ExternID = 872, Referee_City = 'Braunschweig', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Bitter' AND Referee_FirstName = 'Mark'
UPDATE Referee SET Referee_ExternID = 507, Referee_City = 'Halsenbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Boes' AND Referee_FirstName = 'Arno'
UPDATE Referee SET Referee_ExternID = 739, Referee_City = 'Landshut', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Bogenrieder' AND Referee_FirstName = 'J�rgen'
UPDATE Referee SET Referee_ExternID = 2017012101, Referee_City = 'Osterholz-Scharmbeck', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Bohling' AND Referee_FirstName = 'Lars'
UPDATE Referee SET Referee_ExternID = 886, Referee_City = 'Hainburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Botzum' AND Referee_FirstName = 'Jens'
UPDATE Referee SET Referee_ExternID = 2007110401, Referee_City = 'Abstatt', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Brandt' AND Referee_FirstName = 'Joachim'
UPDATE Referee SET Referee_ExternID = 800, Referee_City = 'Falkensee', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Brandt' AND Referee_FirstName = 'Peggy'
UPDATE Referee SET Referee_ExternID = 858, Referee_City = 'Heidelberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Breitenbach' AND Referee_FirstName = 'Johannes'
UPDATE Referee SET Referee_ExternID = 789, Referee_City = 'Limburg/Lahn', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Brinck' AND Referee_FirstName = 'Dagmar'
UPDATE Referee SET Referee_ExternID = 874, Referee_City = 'Lingen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Brinkhoff' AND Referee_FirstName = 'Marc'
UPDATE Referee SET Referee_ExternID = 832, Referee_City = 'Frankfurt', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Bruch' AND Referee_FirstName = 'Susanne'
UPDATE Referee SET Referee_ExternID = 2009032101, Referee_City = 'Zeuthen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Brym' AND Referee_FirstName = 'Daniel'
UPDATE Referee SET Referee_ExternID = 2013111001, Referee_City = 'Ludwigshafen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Br�he' AND Referee_FirstName = 'Beate'
UPDATE Referee SET Referee_ExternID = 879, Referee_City = 'Eilenburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Buschmann' AND Referee_FirstName = 'Steffen'
UPDATE Referee SET Referee_ExternID = 572, Referee_City = 'Leer', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Buschmann' AND Referee_FirstName = 'Heiner'
UPDATE Referee SET Referee_ExternID = 871, Referee_City = 'Sprockh�vel', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'B�umer' AND Referee_FirstName = 'Gerrit'
UPDATE Referee SET Referee_ExternID = 875, Referee_City = 'Porta Westfalica', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'B�hning' AND Referee_FirstName = 'Carsten'
UPDATE Referee SET Referee_ExternID = 797, Referee_City = 'Offenbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Damm' AND Referee_FirstName = 'Manuela'
UPDATE Referee SET Referee_ExternID = 582, Referee_City = 'Hannover', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Danzglock' AND Referee_FirstName = 'Dag'
UPDATE Referee SET Referee_ExternID = 2014111606, Referee_City = 'Wei�enfels', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ebisch' AND Referee_FirstName = 'Laura'
UPDATE Referee SET Referee_ExternID = 2009111502, Referee_City = 'Offenbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Eichelhard' AND Referee_FirstName = 'Kerstin'
UPDATE Referee SET Referee_ExternID = 812, Referee_City = '', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Eimers' AND Referee_FirstName = 'Axel'
UPDATE Referee SET Referee_ExternID = 714, Referee_City = 'N�rnberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Engel' AND Referee_FirstName = 'Steffi'
UPDATE Referee SET Referee_ExternID = 583, Referee_City = 'Rheda-Wiedenbr�ck', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Engelmann' AND Referee_FirstName = 'Erhard'
UPDATE Referee SET Referee_ExternID = 792, Referee_City = 'Ulm', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Erche' AND Referee_FirstName = 'Ilja'
UPDATE Referee SET Referee_ExternID = 2012021104, Referee_City = 'N�rtingen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Faiss' AND Referee_FirstName = 'Christina'
UPDATE Referee SET Referee_ExternID = 850, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Fenske' AND Referee_FirstName = 'Manuel'
UPDATE Referee SET Referee_ExternID = 637, Referee_City = 'Telgte', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Fischer' AND Referee_FirstName = 'Klaus'
UPDATE Referee SET Referee_ExternID = 2011013001, Referee_City = 'Offenbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Fleckenstein' AND Referee_FirstName = 'Claudia'
UPDATE Referee SET Referee_ExternID = 616, Referee_City = 'Velbert', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Franz' AND Referee_FirstName = 'Petra'
UPDATE Referee SET Referee_ExternID = 784, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Fricke' AND Referee_FirstName = 'Timm'
UPDATE Referee SET Referee_ExternID = 2010031401, Referee_City = 'Starnberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Frings' AND Referee_FirstName = 'Felix'
UPDATE Referee SET Referee_ExternID = 2009032102, Referee_City = 'Leipzig', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Fr�hlich' AND Referee_FirstName = 'Holger'
UPDATE Referee SET Referee_ExternID = 876, Referee_City = 'Freiburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Fuchs' AND Referee_FirstName = 'Thorsten'
UPDATE Referee SET Referee_ExternID = 692, Referee_City = 'Havelsee,  OT: Briest', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Garmatter' AND Referee_FirstName = 'Volker'
UPDATE Referee SET Referee_ExternID = 2010012405, Referee_City = 'Kemberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gerhart' AND Referee_FirstName = 'Anja'
UPDATE Referee SET Referee_ExternID = 782, Referee_City = 'Leer', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gerking' AND Referee_FirstName = 'Klaus'
UPDATE Referee SET Referee_ExternID = 713, Referee_City = 'G�sten', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gerlang' AND Referee_FirstName = 'Petra'
UPDATE Referee SET Referee_ExternID = 754, Referee_City = 'Ulm', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gerstenmaier' AND Referee_FirstName = 'Uwe'
UPDATE Referee SET Referee_ExternID = 862, Referee_City = 'Waltrop', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Goer' AND Referee_FirstName = 'Martin'
UPDATE Referee SET Referee_ExternID = 765, Referee_City = 'Duisburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Goldberg' AND Referee_FirstName = 'Holger'
UPDATE Referee SET Referee_ExternID = 838, Referee_City = 'Ahnatal', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gorski' AND Referee_FirstName = 'Torsten'
UPDATE Referee SET Referee_ExternID = 2012021101, Referee_City = 'Regensburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gramann' AND Referee_FirstName = 'Anita'
UPDATE Referee SET Referee_ExternID = 545, Referee_City = 'Bremen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gravert' AND Referee_FirstName = 'Klaus'
UPDATE Referee SET Referee_ExternID = 821, Referee_City = 'Bannewitz', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Greiner' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 607, Referee_City = 'Bonn (Venusberg)', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gr�tzner' AND Referee_FirstName = 'Georg'
UPDATE Referee SET Referee_ExternID = 788, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Gutsche' AND Referee_FirstName = 'Peter'
UPDATE Referee SET Referee_ExternID = 868, Referee_City = 'Aerzen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'G�nter' AND Referee_FirstName = 'Henner'
UPDATE Referee SET Referee_ExternID = 2007110402, Referee_City = 'Traunstein', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Habicht' AND Referee_FirstName = 'Sofia'
UPDATE Referee SET Referee_ExternID = 854, Referee_City = 'Seligenstadt', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Halama' AND Referee_FirstName = 'Peter'
UPDATE Referee SET Referee_ExternID = 2017012104, Referee_City = 'Alt Ruppin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hamdorf' AND Referee_FirstName = 'Svenja'
UPDATE Referee SET Referee_ExternID = 2011013002, Referee_City = 'H�nstetten', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hanfler' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 839, Referee_City = 'Potsdam', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hartmann' AND Referee_FirstName = 'Ulrike'
UPDATE Referee SET Referee_ExternID = 2009111503, Referee_City = 'Offenbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Haux' AND Referee_FirstName = 'Sebastian'
UPDATE Referee SET Referee_ExternID = 2015111401, Referee_City = 'Hanau', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Heinig' AND Referee_FirstName = 'Marie'
UPDATE Referee SET Referee_ExternID = 781, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Heitsch' AND Referee_FirstName = 'Holger'
UPDATE Referee SET Referee_ExternID = 783, Referee_City = 'Otterndorf', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Heitsch' AND Referee_FirstName = 'Torsten'
UPDATE Referee SET Referee_ExternID = 881, Referee_City = '', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Helzel' AND Referee_FirstName = 'Astrid'
UPDATE Referee SET Referee_ExternID = 686, Referee_City = 'Grimma OT Nerchau', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Henne' AND Referee_FirstName = 'Mayk'
UPDATE Referee SET Referee_ExternID = 742, Referee_City = 'Marburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hesse' AND Referee_FirstName = 'Stefan'
UPDATE Referee SET Referee_ExternID = 2011022602, Referee_City = '', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hesselmann' AND Referee_FirstName = 'Lucas'
UPDATE Referee SET Referee_ExternID = 885, Referee_City = 'Marbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hildebrand' AND Referee_FirstName = 'Elke'
UPDATE Referee SET Referee_ExternID = 615, Referee_City = 'Karben', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hillen' AND Referee_FirstName = 'J�rgen'
UPDATE Referee SET Referee_ExternID = 748, Referee_City = 'Woltersdorf', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hintze' AND Referee_FirstName = 'Christian'
UPDATE Referee SET Referee_ExternID = 2013031003, Referee_City = 'Bremem', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Ron'
UPDATE Referee SET Referee_ExternID = 2014111605, Referee_City = 'Chemnitz', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Caroline'
UPDATE Referee SET Referee_ExternID = 845, Referee_City = 'Dresden', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Holger'
UPDATE Referee SET Referee_ExternID = 891, Referee_City = 'W�rzburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Hoffmann' AND Referee_FirstName = 'Martin'
UPDATE Referee SET Referee_ExternID = 895, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ingenh�tt' AND Referee_FirstName = 'J�rg'
UPDATE Referee SET Referee_ExternID = 780, Referee_City = 'Karlsbad', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Jacobs' AND Referee_FirstName = 'Wolfdietrich'
UPDATE Referee SET Referee_ExternID = 2012021105, Referee_City = 'N�rnberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Jaeger' AND Referee_FirstName = 'Martin'
UPDATE Referee SET Referee_ExternID = 2017012103, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Jautzke' AND Referee_FirstName = 'Deborah'
UPDATE Referee SET Referee_ExternID = 882, Referee_City = 'Mei�en', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Jendro�ek' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 2013031001, Referee_City = 'Witten', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'J�ckel' AND Referee_FirstName = 'Christian'
UPDATE Referee SET Referee_ExternID = 603, Referee_City = 'N�rtingen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kaeswurm' AND Referee_FirstName = 'Ulrich'
UPDATE Referee SET Referee_ExternID = 2013111002, Referee_City = 'M�nchen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kaiser' AND Referee_FirstName = 'Jakob'
UPDATE Referee SET Referee_ExternID = 2017012105, Referee_City = 'Wuppertal', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kapeller' AND Referee_FirstName = 'Stefan'
UPDATE Referee SET Referee_ExternID = 625, Referee_City = 'Bochum', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kassler' AND Referee_FirstName = 'Susanne'
UPDATE Referee SET Referee_ExternID = 2012012902, Referee_City = 'Dresden', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Keschka' AND Referee_FirstName = 'Michael'
UPDATE Referee SET Referee_ExternID = 565, Referee_City = 'Heidelberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kienzle-Augspurger' AND Referee_FirstName = 'Monika'
UPDATE Referee SET Referee_ExternID = 901, Referee_City = 'Hannover', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kie�ler' AND Referee_FirstName = 'Stefan'
UPDATE Referee SET Referee_ExternID = 830, Referee_City = 'Bad - D�rkheim', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kilian' AND Referee_FirstName = 'Frank'
UPDATE Referee SET Referee_ExternID = 907, Referee_City = 'Kelsterbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Klauke' AND Referee_FirstName = 'Martin'
UPDATE Referee SET Referee_ExternID = 695, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kleinfeldt' AND Referee_FirstName = 'Rainer'
UPDATE Referee SET Referee_ExternID = 856, Referee_City = 'Mannheim', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kollnig' AND Referee_FirstName = 'Christof'
UPDATE Referee SET Referee_ExternID = 632, Referee_City = 'Bad D�rkheim', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Korgitzsch' AND Referee_FirstName = 'Frank-Michael'
UPDATE Referee SET Referee_ExternID = 744, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Krajewski' AND Referee_FirstName = 'Stephan'
UPDATE Referee SET Referee_ExternID = 461, Referee_City = 'Lindau - Insel', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kramp' AND Referee_FirstName = 'Hans-Juergen'
UPDATE Referee SET Referee_ExternID = 867, Referee_City = 'Greifswald', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Krehl' AND Referee_FirstName = 'Martina'
UPDATE Referee SET Referee_ExternID = 2010031402, Referee_City = 'M�nster', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kreie' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 822, Referee_City = 'M�nchen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kretschmer' AND Referee_FirstName = 'Tobias'
UPDATE Referee SET Referee_ExternID = 2014111603, Referee_City = 'Hannover', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kr�mer' AND Referee_FirstName = 'Sebastian'
UPDATE Referee SET Referee_ExternID = 883, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kuhnert' AND Referee_FirstName = 'Roman'
UPDATE Referee SET Referee_ExternID = 2012012901, Referee_City = 'Werder/Havel', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Kumm-Kottke' AND Referee_FirstName = 'Sibylle'
UPDATE Referee SET Referee_ExternID = 586, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'K�nig' AND Referee_FirstName = 'Klaus-Dieter'
UPDATE Referee SET Referee_ExternID = 778, Referee_City = 'Dresden', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'K�rner' AND Referee_FirstName = 'Annegret'
UPDATE Referee SET Referee_ExternID = 517, Referee_City = '', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Langusch' AND Referee_FirstName = 'Dietmar'
UPDATE Referee SET Referee_ExternID = 2007110405, Referee_City = 'Bremen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Laube' AND Referee_FirstName = 'Tim'
UPDATE Referee SET Referee_ExternID = 904, Referee_City = 'Sche�litz', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Laugwitz' AND Referee_FirstName = 'Eva'
UPDATE Referee SET Referee_ExternID = 639, Referee_City = 'M�nster', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Lechtenboehmer' AND Referee_FirstName = 'Andrea'
UPDATE Referee SET Referee_ExternID = 823, Referee_City = 'Braunschweig', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Lehne' AND Referee_FirstName = 'Frank'
UPDATE Referee SET Referee_ExternID = 2017012106, Referee_City = 'Erlangen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Leube' AND Referee_FirstName = 'Thea'
UPDATE Referee SET Referee_ExternID = 2010012401, Referee_City = 'Wei�enfels', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ludwig' AND Referee_FirstName = 'Steffen'
UPDATE Referee SET Referee_ExternID = 2016021403, Referee_City = 'Kirchm�ser', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Lupke' AND Referee_FirstName = 'Henriette'
UPDATE Referee SET Referee_ExternID = 884, Referee_City = 'Dresden', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'L�ffler' AND Referee_FirstName = 'Rudolf'
UPDATE Referee SET Referee_ExternID = 2014012501, Referee_City = '', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Malota' AND Referee_FirstName = 'Myriam'
UPDATE Referee SET Referee_ExternID = 774, Referee_City = 'Bad Ems', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Mannheim' AND Referee_FirstName = 'Lothar'
UPDATE Referee SET Referee_ExternID = 836, Referee_City = 'Kassel', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Mayer' AND Referee_FirstName = 'Karin-Anne'
UPDATE Referee SET Referee_ExternID = 2009111504, Referee_City = 'Heidelberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Menold' AND Referee_FirstName = 'Klaus'
UPDATE Referee SET Referee_ExternID = 2009111505, Referee_City = 'Heidelberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Menold' AND Referee_FirstName = 'Petra'
UPDATE Referee SET Referee_ExternID = 2010012402, Referee_City = 'Bremen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Mensch' AND Referee_FirstName = 'Martin'
UPDATE Referee SET Referee_ExternID = 645, Referee_City = 'Dresden', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Merz' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 552, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Meyboden' AND Referee_FirstName = 'Gerhard'
UPDATE Referee SET Referee_ExternID = 642, Referee_City = 'Delmenhorst', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Meyer' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 860, Referee_City = 'Riedstadt', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Meyer' AND Referee_FirstName = 'Sebastian'
UPDATE Referee SET Referee_ExternID = 857, Referee_City = 'Hainburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Mieth' AND Referee_FirstName = 'Stefan'
UPDATE Referee SET Referee_ExternID = 796, Referee_City = 'Falkensee', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Molkenthin' AND Referee_FirstName = 'Karen'
UPDATE Referee SET Referee_ExternID = 757, Referee_City = 'Flemhude', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Nehls' AND Referee_FirstName = 'S�nke'
UPDATE Referee SET Referee_ExternID = 861, Referee_City = 'Obertshausen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Niederreuther' AND Referee_FirstName = 'Ralf'
UPDATE Referee SET Referee_ExternID = 2013031002, Referee_City = 'M�nchen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Nikolai' AND Referee_FirstName = 'Joachim'
UPDATE Referee SET Referee_ExternID = 2007110406, Referee_City = 'Hanau', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ocker' AND Referee_FirstName = 'B�rbel'
UPDATE Referee SET Referee_ExternID = 2007110407, Referee_City = 'Hanau', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ocker' AND Referee_FirstName = 'Burkhard'
UPDATE Referee SET Referee_ExternID = 2014111604, Referee_City = 'Leipzig', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Oelze' AND Referee_FirstName = 'Christian'
UPDATE Referee SET Referee_ExternID = 769, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Palfner' AND Referee_FirstName = 'Stefanie'
UPDATE Referee SET Referee_ExternID = 2011013003, Referee_City = 'Bonn', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Pankatz' AND Referee_FirstName = 'Daniel'
UPDATE Referee SET Referee_ExternID = 902, Referee_City = 'Rostock', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Poppitz' AND Referee_FirstName = 'Dirk'
UPDATE Referee SET Referee_ExternID = 2014022301, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Prohn' AND Referee_FirstName = 'Malte'
UPDATE Referee SET Referee_ExternID = 2008110101, Referee_City = 'Hamburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Radke' AND Referee_FirstName = 'Heiko'
UPDATE Referee SET Referee_ExternID = 758, Referee_City = 'Alveslohe', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Rauhut' AND Referee_FirstName = 'Roland'
UPDATE Referee SET Referee_ExternID = 2011013004, Referee_City = 'Dreieich-Dreieichenhain', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ravens-Taeuber' AND Referee_FirstName = 'Gisela'
UPDATE Referee SET Referee_ExternID = 853, Referee_City = 'Dreieich', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Ravens' AND Referee_FirstName = 'Bernd'
UPDATE Referee SET Referee_ExternID = 837, Referee_City = 'Gie�en', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Reppe' AND Referee_FirstName = 'Frank'
UPDATE Referee SET Referee_ExternID = 808, Referee_City = 'Bremen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Reuschling' AND Referee_FirstName = 'Dirk'
UPDATE Referee SET Referee_ExternID = 803, Referee_City = 'Limburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Risse' AND Referee_FirstName = 'Anja'
UPDATE Referee SET Referee_ExternID = 2012021106, Referee_City = 'Waging am See', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Rosemann' AND Referee_FirstName = 'Michael'
UPDATE Referee SET Referee_ExternID = 2010031404, Referee_City = 'Bochum', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Rupieper' AND Referee_FirstName = 'Svenja'
UPDATE Referee SET Referee_ExternID = 835, Referee_City = 'Kassel', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'R�mer' AND Referee_FirstName = 'Holger'
UPDATE Referee SET Referee_ExternID = 2011022603, Referee_City = 'Boppard', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'R�del' AND Referee_FirstName = 'Paloma'
UPDATE Referee SET Referee_ExternID = 577, Referee_City = 'Boppard', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'R�del' AND Referee_FirstName = 'Willi'
UPDATE Referee SET Referee_ExternID = 855, Referee_City = 'Wendelstein', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Scharnagl' AND Referee_FirstName = 'Peter'
UPDATE Referee SET Referee_ExternID = 2012041501, Referee_City = 'M�lheim', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schauenburg' AND Referee_FirstName = 'Maik'
UPDATE Referee SET Referee_ExternID = 892, Referee_City = 'Fuldabr�ck', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schellenberg' AND Referee_FirstName = 'Frank'
UPDATE Referee SET Referee_ExternID = 818, Referee_City = 'Leipzig', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schenk' AND Referee_FirstName = 'Tilman'
UPDATE Referee SET Referee_ExternID = 709, Referee_City = 'Bernburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schiek' AND Referee_FirstName = 'Doris'
UPDATE Referee SET Referee_ExternID = 903, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schirmer' AND Referee_FirstName = 'Oliver'
UPDATE Referee SET Referee_ExternID = 2012021102, Referee_City = 'M�nchen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schmidt' AND Referee_FirstName = 'Martin'
UPDATE Referee SET Referee_ExternID = 2016021401, Referee_City = 'M�lheim (Ruhr)', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schmitz' AND Referee_FirstName = 'Lennert'
UPDATE Referee SET Referee_ExternID = 842, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schmolling' AND Referee_FirstName = 'Philip'
UPDATE Referee SET Referee_ExternID = 816, Referee_City = 'M�nchen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Scholler' AND Referee_FirstName = 'Axel'
UPDATE Referee SET Referee_ExternID = 869, Referee_City = 'Vechelde', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schreiber' AND Referee_FirstName = 'Roland'
UPDATE Referee SET Referee_ExternID = 896, Referee_City = 'Hildesheim', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schroeter' AND Referee_FirstName = 'Stefan'
UPDATE Referee SET Referee_ExternID = 629, Referee_City = 'Kleinmachnow', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schulz' AND Referee_FirstName = 'Tobias'
UPDATE Referee SET Referee_ExternID = 2016021402, Referee_City = 'D�sseldorf', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schumacher' AND Referee_FirstName = 'Valentin'
UPDATE Referee SET Referee_ExternID = 828, Referee_City = 'Heidelberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Schyr' AND Referee_FirstName = 'Christian'
UPDATE Referee SET Referee_ExternID = 745, Referee_City = 'Woltersdorf', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Sch�tzel' AND Referee_FirstName = 'Manfred'
UPDATE Referee SET Referee_ExternID = 2014111602, Referee_City = 'Tangerm�nde', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Seeler' AND Referee_FirstName = 'Ricarda'
UPDATE Referee SET Referee_ExternID = 877, Referee_City = 'Witten', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Seiffert' AND Referee_FirstName = 'Lena'
UPDATE Referee SET Referee_ExternID = 579, Referee_City = 'M�nster', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Siegler' AND Referee_FirstName = 'Holger'
UPDATE Referee SET Referee_ExternID = 201012404, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Sparmann' AND Referee_FirstName = 'Jens'
UPDATE Referee SET Referee_ExternID = 825, Referee_City = 'Oldenburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Spingat' AND Referee_FirstName = 'Frank'
UPDATE Referee SET Referee_ExternID = 2015111402, Referee_City = 'Lobbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Stadler' AND Referee_FirstName = 'Sophie'
UPDATE Referee SET Referee_ExternID = 859, Referee_City = 'Mannheim', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Stephan' AND Referee_FirstName = 'Karin'
UPDATE Referee SET Referee_ExternID = 773, Referee_City = 'Bad Honnef', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Straube' AND Referee_FirstName = 'Klaus'
UPDATE Referee SET Referee_ExternID = 873, Referee_City = 'Witten', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Streckert' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 905, Referee_City = 'Essen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Str�ttchen' AND Referee_FirstName = 'Andre'
UPDATE Referee SET Referee_ExternID = 795, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Terborg' AND Referee_FirstName = 'Oliver'
UPDATE Referee SET Referee_ExternID = 794, Referee_City = 'Friedrichstadt', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Tietgen' AND Referee_FirstName = 'Tobias'
UPDATE Referee SET Referee_ExternID = 2012021103, Referee_City = 'Landsberg am Lech', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Tie�ler' AND Referee_FirstName = 'Michaela'
UPDATE Referee SET Referee_ExternID = 899, Referee_City = 'Bamberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Vercek' AND Referee_FirstName = 'Torsten'
UPDATE Referee SET Referee_ExternID = 720, Referee_City = 'Cottbus', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Vogel' AND Referee_FirstName = 'Helmut'
UPDATE Referee SET Referee_ExternID = 768, Referee_City = 'Feucht', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Walter' AND Referee_FirstName = 'Gerhard'
UPDATE Referee SET Referee_ExternID = 2011022604, Referee_City = 'M�nster', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Warnke' AND Referee_FirstName = 'Nils'
UPDATE Referee SET Referee_ExternID = 621, Referee_City = 'M�nster', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Warnke' AND Referee_FirstName = 'Rolf'
UPDATE Referee SET Referee_ExternID = 634, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wei�' AND Referee_FirstName = 'Bj�rn'
UPDATE Referee SET Referee_ExternID = 2007110403, Referee_City = 'Kriftel', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wei�enberger' AND Referee_FirstName = 'Charlotte'
UPDATE Referee SET Referee_ExternID = 2017012102, Referee_City = 'Ziethen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Westermann' AND Referee_FirstName = 'Tobias'
UPDATE Referee SET Referee_ExternID = 2011022605, Referee_City = 'Duisburg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Weysters' AND Referee_FirstName = 'Tobias'
UPDATE Referee SET Referee_ExternID = 864, Referee_City = 'K�ln', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wiesner' AND Referee_FirstName = 'Jens'
UPDATE Referee SET Referee_ExternID = 829, Referee_City = 'Heidelberg', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wilz' AND Referee_FirstName = 'Volker'
UPDATE Referee SET Referee_ExternID = 826, Referee_City = 'Kaiseraugst', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wilz' AND Referee_FirstName = 'R�diger'
UPDATE Referee SET Referee_ExternID = 798, Referee_City = 'Offenbach', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Winter' AND Referee_FirstName = 'Manfred'
UPDATE Referee SET Referee_ExternID = 906, Referee_City = 'Ulm', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Witt' AND Referee_FirstName = 'Thomas'
UPDATE Referee SET Referee_ExternID = 702, Referee_City = 'Potsdam', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wujanz' AND Referee_FirstName = 'Harald'
UPDATE Referee SET Referee_ExternID = 893, Referee_City = 'M�nchen', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wulf' AND Referee_FirstName = 'Dennis'
UPDATE Referee SET Referee_ExternID = 678, Referee_City = 'Leipzig', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Wuwer' AND Referee_FirstName = 'Sven'
UPDATE Referee SET Referee_ExternID = 2014022302, Referee_City = 'Krefeld', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'W�stemeyer' AND Referee_FirstName = 'Eva'
UPDATE Referee SET Referee_ExternID = 2014111601, Referee_City = 'Berlin', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Zillmann' AND Referee_FirstName = 'Fabian'
UPDATE Referee SET Referee_ExternID = 807, Referee_City = 'Hanau', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Z�ger' AND Referee_FirstName = 'Andrea'
UPDATE Referee SET Referee_ExternID = 599, Referee_City = 'Schallstadt', Referee_Nation_ID_FK = @Nat_ID_GER WHERE Referee_LastName = 'Z�llner' AND Referee_FirstName = 'Volker'

-- SELECT COUNT(Referee_ID) AS 'aktualisiert' FROM Referee WHERE Referee_ExternID > 0
