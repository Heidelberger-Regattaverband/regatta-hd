SELECT
	Crew_Club_ID_FK,
	Club_Abbr,
	WinCount,
	WinRank
FROM (
	SELECT
		Crew_Club_ID_FK,
		COUNT(Crew_Club_ID_FK) AS WinCount,
		RANK() OVER (ORDER BY COUNT(Crew_Club_ID_FK) DESC) AS WinRank
	FROM
		(SELECT
			CE_Entry_ID_FK, Crew_Club_ID_FK
		FROM CompEntries
			JOIN Entry ON Entry_ID = CE_Entry_ID_FK
			JOIN Crew ON Crew_Entry_ID_FK = CE_Entry_ID_FK AND Crew_IsCox = 0 AND Crew_RoundTo = 64
			JOIN Comp ON Comp_ID = CE_Comp_ID_FK
			JOIN Result ON (Result_CE_ID_FK = CE_ID)
		WHERE
			Entry_Event_ID_FK = %event% AND
			Comp_Round = 64 AND ((Comp_RoundCode = 'F' AND Comp_HeatNumber = 1) OR Comp_RoundCode IN ('A', 'R')) AND
			Crew_RoundTo = Comp_Round AND
			Result_SplitNr = 64 AND Result_Rank = 1
		GROUP BY
			CE_Entry_ID_FK, Crew_Club_ID_FK
		) AS WinStats
	GROUP BY
		Crew_Club_ID_FK
	) AS WinStats
	JOIN Club ON Club_ID = Crew_Club_ID_FK
WHERE
	WinRank <= 10
ORDER BY
	WinCount DESC
