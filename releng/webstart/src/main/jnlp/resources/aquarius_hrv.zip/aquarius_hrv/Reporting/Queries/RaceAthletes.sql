SELECT DISTINCT
    Athlet_ID,
    Athlet_LastName,
    Athlet_FirstName,
    Athlet_Gender,
    YEAR(Athlet_DOB) AS Athlet_YOB,
    Athlet_Club_ID_FK,
    Athlet_ExternID_A,
    Athlet_State,
    Club_UltraAbbr
FROM
    Crew
    LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
    LEFT JOIN Athlet ON Crew_Athlete_ID_FK = Athlet_ID
    LEFT JOIN Club ON Club_ID = Crew_Club_ID_FK
WHERE
    Entry_Race_ID_FK = %race%
ORDER BY
    Athlet_LastName,
    Athlet_FirstName
