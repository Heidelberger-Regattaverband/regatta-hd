SELECT
	Crew_Club_ID_FK AS Club_ID,
	Result_Rank AS Rank,
	COUNT (DISTINCT Entry_ID) AS Cnt
FROM CompEntries
	LEFT JOIN Entry ON Entry_ID = CE_Entry_ID_FK
	JOIN Crew ON (Crew_Entry_ID_FK = CE_Entry_ID_FK AND Crew_IsCox = 0 AND Crew_RoundTo = 64)
	LEFT JOIN Comp ON Comp_ID = CE_Comp_ID_FK
	JOIN Result ON (Result_CE_ID_FK = CE_ID AND Result_SplitNr = 64 AND Result_ResultType = 'N')
WHERE
	Entry_Event_ID_FK = %event% AND
	Comp_Round = 64 AND (Comp_RoundCode = 'F' AND Comp_HeatNumber = 1 OR Comp_RoundCode IN ('A', 'R') AND Comp_State = 4)
GROUP BY
	Crew_Club_ID_FK, Result_Rank
ORDER BY
	Rank ASC,
	Cnt DESC
