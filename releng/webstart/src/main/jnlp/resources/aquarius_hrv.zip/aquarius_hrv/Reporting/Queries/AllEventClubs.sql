--- Ermittelt alle Vereine, von denen Sportler gemeldet wurden
--- zu Unterscheiden von der Liste aller Verein, die Meldungen abgegeben haben!

SELECT DISTINCT
	Club_ID,
	Club_City,
	Club_Name,
	Club_Abbr,
	Club_UltraAbbr,
	Club_ExternID,
	Nation_IOC_Code
FROM
	Crew
	LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	LEFT JOIN Club ON Crew_Club_ID_FK = Club_ID
	LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
WHERE
	Entry_Event_ID_FK = %event%
ORDER BY
	Club_City,
	Club_Name
