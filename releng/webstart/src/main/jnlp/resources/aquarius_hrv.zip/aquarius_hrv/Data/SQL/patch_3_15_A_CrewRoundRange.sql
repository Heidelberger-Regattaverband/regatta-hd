-- Switch crew member storage model
-- Crew members are not stored with their first round they appeared in anymore,
-- but with a range of rounds they compete in. Range limits are inclusive.
-- This makes selecting the crew of a particular round far more easy than using
-- CTEs all over the place. However care must be taken when storing crew members
-- and changes in entries. The stored ranged MUST NOT overlap.
-- Examples:
--  * An Athlete Competes in an entry from entry until final round
--     -> RoundFrom = 0, RoundTo = 64
--  * Athlete A is entered and competes until the first round, he/she is then
--    replaced by an athlete B (he/she competes from repechage round until final)
--     A: RoundFrom = 0, RoundTo = 4
--     B: RoundFrom = 8, RoundTo = 64
--  * As above but with the substitution for the final round
--     A: RoundFrom = 0, RoundTo = 32
--     B: RoundFrom = 64, RoundTo = 64
--  * Athlete A is only entered, but does not compete (replaced before first round)
--     A: RoundFrom = 0, RoundTo = 0
--     B: RoundFrom = 4, RoundTo = 64
--
-- Select competing crew members with (WHERE RoundFrom <= Round AND Round <= RoundTo)

ALTER TABLE
	Crew
ADD
	Crew_RoundFrom SMALLINT NOT NULL DEFAULT 0,
	Crew_RoundTo SMALLINT NOT NULL DEFAULT 0
GO

DECLARE @NoRoundMarker AS SMALLINT = 128

-- data migration
-- 1. Copy old Crew_Round to Crew_Round_From
UPDATE Crew SET Crew_RoundFrom = Crew_Round

-- 2. set RoundTo to invalid default fist
UPDATE Crew SET Crew_RoundTo = @NoRoundMarker

-- 3. Easy Migration: All changes for the final round do not have any other changes
UPDATE Crew SET Crew_RoundTo = 64 WHERE Crew_RoundFrom = 64

-- 4. Set RoundTo to next higher round or final if no higher one is present
DECLARE
	@Member_ID INT,
	@Entry_ID_FK INT,
	@Pos TINYINT,
	@RoundFrom SMALLINT,
	@NextPosRound SMALLINT

DECLARE CrewMembers CURSOR LOCAL FORWARD_ONLY FOR
SELECT Crew_ID, Crew_Entry_ID_FK, Crew_Pos, Crew_RoundFrom FROM Crew WHERE Crew_RoundTo = @NoRoundMarker
FOR UPDATE OF Crew_RoundTo

OPEN CrewMembers

FETCH NEXT FROM CrewMembers INTO @Member_ID, @Entry_ID_FK, @Pos, @RoundFrom
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @NextPosRound = (
		SELECT
			COALESCE(MIN(Crew_RoundFrom), 64 * 2)
		FROM
			Crew
		WHERE
			Crew_Entry_ID_FK = @Entry_ID_FK
			AND Crew_Pos = @Pos
			AND Crew_ID <> @Member_ID
			AND Crew_RoundFrom > @RoundFrom
	)
	UPDATE Crew SET Crew_RoundTo = @NextPosRound / 2 WHERE CURRENT OF CrewMembers
	FETCH NEXT FROM CrewMembers INTO @Member_ID, @Entry_ID_FK, @Pos, @RoundFrom
END

CLOSE CrewMembers
DEALLOCATE CrewMembers

-- 5. remove unused/invalid RoundTo value of 2 (crew member was only entered for the entry)
UPDATE Crew SET Crew_RoundTo = 0 WHERE Crew_RoundTo = 2 AND Crew_RoundFrom = 0

--- SELECT * FROM Crew

-- Drop default value constraint (with unknown name) first.
-- What a mess for such a simple thing.
DECLARE @constraint_name NVARCHAR(256)

SELECT
	@constraint_name = constr.name
FROM
	sys.tables tbls
	JOIN sys.default_constraints constr ON constr.parent_object_id = tbls.object_id
	JOIN sys.columns cols ON cols.object_id = tbls.object_id AND cols.column_id = constr.parent_column_id
WHERE
	tbls.name = 'Crew' AND cols.name = 'Crew_Round'

EXEC(N'ALTER TABLE Crew DROP CONSTRAINT ' + @constraint_name)

-- Drop old column.
ALTER TABLE
	Crew
DROP
	COLUMN Crew_Round
