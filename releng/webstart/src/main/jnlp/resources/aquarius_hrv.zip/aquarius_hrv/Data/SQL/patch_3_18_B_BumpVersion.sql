--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.18'
WHERE
	MetaData_Key = 'PatchLevel'
