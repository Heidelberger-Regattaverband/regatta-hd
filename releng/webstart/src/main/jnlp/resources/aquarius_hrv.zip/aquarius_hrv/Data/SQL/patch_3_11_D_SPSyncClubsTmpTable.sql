ALTER PROCEDURE SyncClubs
	-- Add the parameters for the stored procedure here
	@SyncOnly BIT = 0
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- variables
	DECLARE @Nation_GER_FK_ID INT


	-- var init
	SET @Nation_GER_FK_ID = (SELECT Nation_ID FROM Nation WHERE Nation_IOC_Code = 'GER')

	-- sync data
	UPDATE
		Club
	SET
		Club_Name = x_name,
		Club_Abbr = x_abbr,
		Club_UltraAbbr = x_uabbr,
		Club_City = x_loc,
		Club_ExternID = x_id
	FROM
		#tmp_clubs
	WHERE
		#tmp_clubs.x_ID = Club_ExternID


	-- insert new data
	IF @SyncOnly = 0
	BEGIN
		-- delete data that is already synced
		DELETE FROM
			#tmp_clubs
		WHERE
			(SELECT
				COUNT(Club_ID)
			FROM
				Club
			WHERE
				Club_ExternID = x_ID) > 0


		-- insert new data
		INSERT INTO
			Club
			(Club_Name, Club_Abbr, Club_UltraAbbr, Club_City, Club_ExternID, Club_Nation_ID_FK)
		SELECT
			x_name,
			x_abbr,
			x_uabbr,
			x_loc,
			x_ID,
			@Nation_GER_FK_ID
		FROM
			#tmp_clubs
	END

END