SELECT 
    Entry_ID,
    Entry_Race_ID_FK,
    Entry_Bib,
    TRIM(ISNULL(Entry_BibPrefix, ' ') + CAST(Entry_BIB AS VARCHAR)) AS Entry_FullBib,
    Entry_Comment,
    Entry_CancelValue,
    Entry_GroupValue,
    Entry_Note
FROM
    CompEntries
    LEFT JOIN Entry ON CE_Entry_ID_FK = Entry_ID
WHERE
    CE_Comp_ID_FK = %comp%
