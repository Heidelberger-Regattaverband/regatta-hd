SELECT
    CE_ID,
    CE_Comp_ID_FK,
    CE_Entry_ID_FK,
    CE_Lane
FROM
    CompEntries
    LEFT JOIN Comp ON Comp_ID = CE_Comp_ID_FK
WHERE
    Comp_Race_ID_FK = %race% AND
    Comp_Round = %round%