SELECT 
	CompReferee.*
FROM
	CompReferee
	LEFT JOIN Referee ON CompReferee_Referee_ID_FK = Referee_ID
	LEFT JOIN Comp ON CompReferee_Comp_ID_FK = Comp_ID
	LEFT JOIN Offer ON Comp_Race_ID_FK = Offer_ID
WHERE
	Offer_Event_ID_FK = %event%
ORDER BY
	Offer_ID,
	Comp_ID,
	Referee_LastName,
	Referee_FirstName