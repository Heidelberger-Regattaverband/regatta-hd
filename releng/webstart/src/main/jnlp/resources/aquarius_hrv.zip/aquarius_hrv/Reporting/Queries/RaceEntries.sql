SELECT 
    Entry_ID,
    Entry_Race_ID_FK, --- required for getting crew string
    Entry_Bib,
    TRIM(ISNULL(Entry_BibPrefix, ' ') + CAST(Entry_BIB AS VARCHAR)) AS Entry_FullBib,
    Entry_Comment,
    Entry_CancelValue,
    Entry_GroupValue,
    Entry_Note,
    Nation_IOC_Code
FROM
    Entry
    LEFT JOIN Club ON Club_ID = Entry_OwnerClub_ID_FK
    LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
WHERE
    Entry_Race_ID_FK = %race%
