SELECT
	-- explicit select of columns because some of them are overriden but keep their name to
	-- remain compatible with result report
	Result_CE_ID_FK,
	Result_SplitNr,
	Result_DayTime,
	Result_NetTime,
	Result_NetTime - MIN (Result_NetTime) OVER (PARTITION BY Result_SplitNr) AS Result_Delta,
	RANK() OVER (PARTITION BY Result_SplitNr ORDER BY Result_SortValue) AS Result_Rank,
	Result_SortValue,
	Result_DisplayValue,
	Result_Params,
	Result_ResultType,
	Result_DisplayType,
	Result_Comment
FROM
	Result
	LEFT JOIN CompEntries ON Result_CE_ID_FK = CE_ID
	LEFT JOIN Comp ON CE_Comp_ID_FK = Comp_ID
WHERE
	Comp_Race_ID_FK = %race%
	AND Comp_Round = %round%
ORDER BY
	CE_Entry_ID_FK,
	Result_SplitNr