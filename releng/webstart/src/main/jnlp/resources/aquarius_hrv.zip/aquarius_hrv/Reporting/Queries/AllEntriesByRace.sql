SELECT 
	Entry.*,
	TRIM(ISNULL(Entry_BibPrefix, ' ') + CAST(Entry_BIB AS VARCHAR)) AS Entry_FullBib,
	Offer.*,
	Nation.Nation_IOC_Code
FROM
	Entry
	LEFT JOIN Offer ON Entry_Race_ID_FK = Offer_ID
	LEFT JOIN Club ON Club_ID = Entry_OwnerClub_ID_FK
	LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
WHERE
	Entry_Event_ID_FK = %event%
ORDER BY
	Offer_SortValue
