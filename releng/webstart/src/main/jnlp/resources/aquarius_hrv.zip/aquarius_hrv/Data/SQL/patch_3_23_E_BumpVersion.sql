--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.23'
WHERE
	MetaData_Key = 'PatchLevel'
