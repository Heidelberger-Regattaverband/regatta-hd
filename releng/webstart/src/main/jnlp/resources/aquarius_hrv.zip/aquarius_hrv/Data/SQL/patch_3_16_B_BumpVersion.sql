--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.16'
WHERE
	MetaData_Key = 'PatchLevel'
