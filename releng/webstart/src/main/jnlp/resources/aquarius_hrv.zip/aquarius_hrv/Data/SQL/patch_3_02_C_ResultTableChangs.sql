--- drop old PK, drop obsolete PK column and create new 2-column-based PK
ALTER TABLE 
    Result 
DROP 
    CONSTRAINT PK_Result,
    COLUMN Result_ID
    
ALTER TABLE 
    Result  
ADD  
    CONSTRAINT PK_Result PRIMARY KEY CLUSTERED (
        Result_CE_ID_FK ASC,
        Result_SplitNr ASC) 
    WITH (
        PAD_INDEX  = OFF, 
        STATISTICS_NORECOMPUTE  = OFF, 
        SORT_IN_TEMPDB = OFF, 
        IGNORE_DUP_KEY = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS  = ON, 
        ALLOW_PAGE_LOCKS  = ON) 
    ON [PRIMARY];


--- increase patch level
UPDATE 
	MetaData
SET
	MetaData_Value = '3.2'
WHERE
	MetaData_Key = 'PatchLevel'