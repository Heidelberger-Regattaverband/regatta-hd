SELECT
	Comp_ID,
	Comp_Race_ID_FK,
	Comp_Event_ID_FK,
	Comp_Round,
	Comp_HeatNumber,
	Comp_RoundCode,
	Comp_Label,
	Comp_GroupValue,
	Comp_DateTime,
	Comp_State,
	Comp_Number,
	Comp_Locked,
	Comp_Dummy,
	Comp_Cancelled,
	Comp_RMDetail_ID_FK,
	ISNULL(Comp_Distance, Offer_Distance) AS Comp_Distance,
	RMLap_QRText AS Comp_RuleText
FROM
	Comp
	JOIN Offer ON Offer_ID = Comp_Race_ID_FK
	LEFT JOIN RaceMode_Detail ON Comp_RMDetail_ID_FK = RMLap_ID 
WHERE
	Comp_ID = %comp%
