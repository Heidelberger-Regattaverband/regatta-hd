DECLARE @DupCount INT

SET @DupCount = (
	SELECT 
		COUNT(*) AS DupCount 
	FROM (
		SELECT 
			Result.Result_CE_ID_FK, 
			Result.Result_SplitNr,
			COUNT(*) AS TotalCount
		FROM 
			Result
		GROUP BY 
			Result.Result_CE_ID_FK,
			Result.Result_SplitNr
		HAVING 
			COUNT(*) > 1
	) AS Dups
)

SELECT CASE @DupCount WHEN 0 THEN 'Update possible' ELSE 'Sorry' END AS Message
