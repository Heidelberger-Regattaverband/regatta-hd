SELECT TOP 10
	*
FROM
	(SELECT 
		Club_Abbr,
		COUNT(DISTINCT(Athlet_ID)) AS Cnt,
		RANK() OVER (ORDER BY COUNT(DISTINCT(Athlet_ID)) DESC) AS 'Rank'
	FROM
		Crew 
		LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
		LEFT JOIN Athlet ON Crew_Athlete_ID_FK = Athlet_ID
		LEFT JOIN Club ON Crew_Club_ID_FK = Club_ID
	WHERE 
		Entry_Event_ID_FK = %event%
	GROUP BY
		Club_Abbr,
		Athlet_Club_ID_FK) AS tmp
WHERE
	Rank <= 5
ORDER BY
	Rank
