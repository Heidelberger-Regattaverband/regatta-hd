ALTER PROCEDURE UpdateEntryLabels
	@Entry INT,
	@TeamPrefix VARCHAR(8)
AS

--- for future use
DECLARE @Round SMALLINT = 64

--- variables
DECLARE @short VARCHAR(255)
DECLARE @long VARCHAR(512)
DECLARE @count TINYINT = 0

DECLARE @owner_short VARCHAR(255)
DECLARE @owner_long VARCHAR(512)

--- fetch owner club data
SELECT
	@owner_short = Club_Abbr,
	@owner_long = Club_Name
FROM
	Entry
	JOIN Club ON Club.Club_ID = Entry.Entry_OwnerClub_ID_FK
WHERE
	Entry.Entry_ID = @Entry;

--- compute labels (note that the names are not fetched in crew order which would be nicer)
WITH Clubs_Names (Club_Abbr, Club_Name) AS
(
	SELECT
		DISTINCT
		Club_Abbr,
		Club_Name
	FROM
		Crew c1
		LEFT OUTER JOIN Crew c2 on (
			c1.Crew_Entry_ID_FK = c2.Crew_Entry_ID_FK
			AND c1.Crew_Pos = c2.Crew_Pos
			AND c1.Crew_Round < c2.Crew_Round
			AND c2.Crew_Round <= @Round
		)
		JOIN Club ON c1.Crew_Club_ID_FK = Club_ID
	WHERE
		c1.Crew_Entry_ID_FK = @Entry
		AND c2.Crew_ID IS NULL
		AND c1.Crew_Round <= @Round
) SELECT
	@short = LTRIM(RTRIM(COALESCE(@short + ' / ' + Club_Abbr, Club_Abbr))),
	@long = LTRIM(RTRIM(COALESCE(@long + ' / ' + Club_Name, Club_Name))),
	@count = @count + 1
FROM
	Clubs_Names;

--- update entry data
UPDATE
	Entry
SET
	Entry_LongLabel = CASE
		WHEN @count = 0 THEN @owner_long
		WHEN @count = 1 THEN @long
		ELSE @TeamPrefix + ' ' +  @long
		END,
	Entry_ShortLabel = CASE
		WHEN @count = 0 THEN @owner_short
		WHEN @count = 1 THEN @short
		ELSE @TeamPrefix + ' ' + @short
		END,
	Entry_IsTeam = CASE
		WHEN @count > 1 THEN 1
		ELSE 0
		END
WHERE
	Entry_ID = @Entry
GO

--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.13'
WHERE
	MetaData_Key = 'PatchLevel'