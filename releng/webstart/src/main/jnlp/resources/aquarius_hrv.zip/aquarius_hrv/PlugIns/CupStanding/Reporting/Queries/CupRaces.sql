SELECT 
	Offer_ID AS ID,
	Offer_RaceNumber AS RaceNumber,
	Offer_LongLabel AS LongLabel,
	Offer_ShortLabel AS ShortLabel
FROM
	Offer
	INNER JOIN Cup ON Cup.Race_ID_FK = Offer_ID AND Cup.Parent_ID = %option:cup_id%
ORDER BY
	Offer_Event_ID_FK,
	Offer_SortValue