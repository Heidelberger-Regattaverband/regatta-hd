ALTER PROCEDURE UpdateEntryLabels
	@EntryID INT,
	@TeamPrefix VARCHAR(8)
AS BEGIN
	DECLARE @manual_label_id AS INT = (SELECT Entry_ManualLabel_ID_FK FROM Entry WHERE Entry_ID = @EntryID)

	IF @manual_label_id IS NOT NULL
	BEGIN
		-- Delete all other labels, if any.
		DELETE FROM EntryLabel WHERE EL_Entry_ID_FK = @EntryID AND EL_RoundFrom > 0
		IF EXISTS (SELECT EL_ID FROM EntryLabel WHERE EL_Entry_ID_FK = @EntryID AND EL_RoundFrom = 0)
			UPDATE EntryLabel SET EL_Label_ID_FK = @manual_label_id, EL_RoundTo = 64 WHERE EL_Entry_ID_FK = @EntryID AND EL_RoundFrom = 0
		ELSE
			INSERT INTO EntryLabel (EL_Entry_ID_FK, EL_Label_ID_FK, EL_RoundFrom, EL_RoundTo) VALUES (@EntryID, @manual_label_id, 0, 64)

		-- nothing more todo
		RETURN
	END

	DECLARE @round_from AS INT = 0
	DECLARE @round_to AS INT = 0

	DECLARE @next_change AS INT = -1
	-- required flag for entry label SP
	DECLARE @first_update AS BIT = 1

	WHILE @next_change < 64
	BEGIN
		-- Find the next round where a crew member changes
		SELECT TOP 1 @next_change = RoundFrom FROM (
			SELECT Crew_RoundFrom AS RoundFrom FROM Crew
			WHERE (Crew_Entry_ID_FK = @EntryID) AND (Crew_RoundFrom > @round_from)
			UNION
			SELECT 64 * 2 -- fallback to ensure the final round is covered (see division below)
		) AS Stat ORDER BY RoundFrom ASC

		SET @next_change = @next_change / 2

		--- PRINT 'update ' + CAST(@round_from AS VARCHAR) + ' -> ' + CAST(@next_change AS VARCHAR)
		EXEC UpdateEntryLabel @EntryID, @round_from, @round_to, @first_update, @TeamPrefix
		SET @first_update = 0

		-- advance to the next round
		SET @round_from = @next_change * 2
	END
END