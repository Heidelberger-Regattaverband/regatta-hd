SELECT DISTINCT
	Referee.*,
	Nation.*
FROM
	Referee
	LEFT JOIN Nation ON Referee_Nation_ID_FK = Nation_ID
	LEFT JOIN EventReferee ON ER_Referee_ID_FK = Referee_ID
	LEFT JOIN CompReferee ON Referee_ID = CompReferee_Referee_ID_FK
	LEFT JOIN Comp ON CompReferee_Comp_ID_FK = Comp_ID
	LEFT JOIN Offer ON Comp_Race_ID_FK = Offer_ID
WHERE
	Offer_Event_ID_FK = %event% OR
	ER_Event_ID_FK = %event%
ORDER BY
	Referee_LastName,
	Referee_FirstName