SELECT 
	RANK() OVER (PARTITION BY Comp_GroupValue ORDER By Comp_HeatNumber, Result_Rank) AS Result_GroupRank,	
	Result_Rank,
	Result_DisplayValue,
	Result_DisplayType,
	Result_ResultType,
	Comp_ID AS Result_Comp_ID,
	Entry_ID AS Result_Entry_ID
FROM
	Result
	JOIN CompEntries ON Result_CE_ID_FK = CE_ID
	JOIN Comp ON CE_Comp_ID_FK = Comp_ID
	JOIN Entry ON CE_Entry_ID_FK = Entry_ID
WHERE
	Entry_Race_ID_FK = %race% AND
	Comp_Round = 64 AND
	Result_SplitNr = 64 AND
	Result_ResultType = 'N'
ORDER BY
	Comp_GroupValue,
	Comp_HeatNumber,
	Result_Rank
