-- update cox limits according to latest rule changes
UPDATE
	AgeClass
SET
	AgeClass_LW_CoxLowerLimit = 55000,
	AgeClass_LW_CoxTolerance = 15000
WHERE
	AgeClass_MaxAge > 14

-- no coxes weights for child races and master races
UPDATE
	AgeClass
SET
	AgeClass_LW_CoxLowerLimit = NULL,
	AgeClass_LW_CoxTolerance = NULL
WHERE
	AgeClass_MaxAge <= 14
-- rule interpretation: no cox limits for master race
	OR (AgeClass_Abbr LIKE 'MM%' OR AgeClass_Abbr LIKE 'MW%')

-- fix a bug in existing installations
UPDATE
	AgeClass
SET
	AgeClass_AllowYounger = 1
WHERE
	(AgeClass_Abbr LIKE 'SF%' OR AgeClass_Abbr LIKE 'SM%')