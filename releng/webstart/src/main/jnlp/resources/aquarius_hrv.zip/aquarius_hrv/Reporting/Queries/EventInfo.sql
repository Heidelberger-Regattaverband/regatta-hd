SELECT
	Event.*,
	Club_Name,
	Club_Abbr,
	ISNULL(Nation_IOC_Code, 'GER') AS Venue_Nation_Code
FROM
	Event
	LEFT JOIN Club ON Event_Club_ID_FK = Club_ID
	LEFT JOIN Nation ON Nation_ID = Event_Venue_Nation_ID_FK
WHERE
	Event_ID = %event%
