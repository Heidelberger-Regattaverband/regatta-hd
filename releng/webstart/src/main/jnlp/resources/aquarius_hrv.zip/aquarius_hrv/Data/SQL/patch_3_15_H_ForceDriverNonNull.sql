-- ensure force_driven and is_lightweight behave like a Booleans

UPDATE Offer SET Offer_ForceDriven = 0 WHERE Offer_ForceDriven IS NULL
ALTER TABLE Offer ALTER COLUMN Offer_ForceDriven BIT NOT NULL
ALTER TABLE Offer ADD CONSTRAINT DF_Offer_Offer_ForceDriven DEFAULT 0 FOR Offer_ForceDriven

UPDATE Offer SET Offer_IsLightweight = 0 WHERE Offer_IsLightweight IS NULL
ALTER TABLE Offer ALTER COLUMN Offer_IsLightweight BIT NOT NULL
ALTER TABLE Offer ADD CONSTRAINT DF_Offer_Offer_IsLightweight DEFAULT 0 FOR Offer_IsLightweight

--
