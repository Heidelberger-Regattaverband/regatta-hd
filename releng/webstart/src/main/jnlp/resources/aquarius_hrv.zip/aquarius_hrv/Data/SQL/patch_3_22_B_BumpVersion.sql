--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.22'
WHERE
	MetaData_Key = 'PatchLevel'
