SELECT 
	Offer_ID,
	Offer_Event_ID_FK,
	Offer_RaceNumber,
	Offer_LongLabel,
	Offer_ShortLabel,
	Offer_Comment,
	Offer_Prize,
	Offer_EventDay,
	Offer_Distance,
	Offer_GroupMode,
	Offer_RaceType,
	REPLACE(ISNULL(Offer_Fee, 0), ',', '.') AS Offer_Fee,
	CAST(Offer_Driven AS INT) AS Offer_Driven,
	CAST(Offer_Cancelled AS INT) AS Offer_Cancelled,
	BoatClass_NumRowers,
	CAST(BoatClass_Coxed AS INT) AS BoatClass_Coxed
FROM
	Offer
	LEFT JOIN BoatClass ON BoatClass_ID = Offer_BoatClass_ID_FK 
WHERE
	Offer_Event_ID_FK = %event%
ORDER BY
	Offer_SortValue
