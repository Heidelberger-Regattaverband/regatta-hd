SELECT 
	Entry_ID,
	Entry_Race_ID_FK,
	Entry_OwnerClub_ID_FK,
	Entry_Event_ID_FK,
	Entry_Bib,
	TRIM(ISNULL(Entry_BibPrefix, ' ') + CAST(Entry_BIB AS VARCHAR)) AS Entry_FullBib,
	Entry_BoatNumber,
	Entry_Comment,
	Entry_GroupValue,
	Entry_CancelValue,
	Entry_ExternID,
	Entry_Note,
	Label_Short,
	Label_Long,
	CAST(Entry_IsLate AS INT) Entry_IsLate,
	Nation_IOC_Code
FROM
	Entry
	LEFT JOIN Club ON Club_ID = Entry_OwnerClub_ID_FK
	LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
	-- use labels from the entry
	JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID AND EL_RoundFrom = 0
	JOIN Label ON Label_ID = EL_Label_ID_FK
WHERE
	Entry_Event_ID_FK = %event%
ORDER BY
	Entry_Race_ID_FK,
	Entry_Bib,
	Entry_GroupValue	
