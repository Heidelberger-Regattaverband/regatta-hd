SELECT
	Offer_ID,
	Offer_RaceNumber,
	Offer_LongLabel,
	Offer_ShortLabel,
	Offer_Comment,
	Offer_Distance,
	Offer_GroupMode,
	Offer_AgeClass_ID_FK,
	CAST(Offer_Driven AS INT) AS Offer_Driven,
	CAST(Offer_Cancelled AS INT) AS Offer_Cancelled,
	BoatClass_NumRowers,
	CASE WHEN BoatClass_Coxed = 1 AND NOT (AgeClass_MaxAge < 15) THEN 1 ELSE 0 END AS Weigh_Cox,
	CASE WHEN Offer_IsLightweight = 1 THEN 1 ELSE 0 END AS Weigh_Athlete
FROM
	Offer
	LEFT JOIN BoatClass ON BoatClass_ID = Offer_BoatClass_ID_FK
	LEFt JOIN AgeClass ON AgeClass_ID = Offer_AgeClass_ID_FK
WHERE
	Offer_Event_ID_FK = %event%
	AND (BoatClass_Coxed = 1 AND NOT (AgeClass_MaxAge < 15)) OR Offer_IsLightweight = 1
	AND Offer_Driven = 1
	AND Offer_Cancelled = 0
