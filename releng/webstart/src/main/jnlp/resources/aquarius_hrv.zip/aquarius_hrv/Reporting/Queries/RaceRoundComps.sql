SET LANGUAGE GERMAN
SELECT 
    Comp_ID,
    Comp_Race_ID_FK,
    Comp_Round,
    Comp_HeatNumber,
    Comp_RoundCode,
    Comp_Label,
    Comp_GroupValue,
    Comp_DateTime,
    Comp_State,
    Comp_Number,
    ISNULL(Comp_Distance, Offer_Distance) AS Comp_Distance,
    DATEPART(hh, Comp_DateTime) AS Comp_Hour,
    DATEPART(n, Comp_DateTime) AS Comp_Minute,  
    CAST(Comp_Cancelled AS INT) AS Comp_Cancelled,
    CAST(Comp_Dummy AS INT) AS Comp_Dummy,
    RMLap_QRText AS Comp_RuleText
FROM
    Comp
    JOIN Offer ON Offer_ID = Comp_Race_ID_FK
    LEFT JOIN RaceMode_Detail ON Comp_RMDetail_ID_FK = RMLap_ID
WHERE
    Comp_Race_ID_FK = %race% AND
    Comp_Round = %round% AND
    Comp_DateTime IS NOT NULL
ORDER BY
    Comp_DateTime
