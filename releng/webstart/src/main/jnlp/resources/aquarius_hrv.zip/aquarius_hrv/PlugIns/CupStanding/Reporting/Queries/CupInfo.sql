SELECT 
	Caption,
	(
		SELECT 
			COUNT(DISTINCT Comp_ID)
		FROM 
			Cup
			INNER JOIN CupPointTable ON CupPointTable.Parent_ID = Cup.PointTable_ID_FK
			INNER JOIN Comp ON (Comp_Race_ID_FK = Race_ID_FK) AND (CupPointTable.Round = Comp_Round) AND ((CupPointTable.Lap = Comp_HeatNumber OR CupPointTable.Lap IS NULL))
		WHERE 
			Comp_Cancelled = 0 AND
			Cup.Parent_ID = %option:cup_id%
	) AS NumComps,
	(
		SELECT 
			COUNT(DISTINCT Comp_ID)
		FROM 
			Cup
			INNER JOIN CupPointTable ON CupPointTable.Parent_ID = Cup.PointTable_ID_FK
			INNER JOIN Comp ON (Comp_Race_ID_FK = Race_ID_FK) AND (CupPointTable.Round = Comp_Round) AND ((CupPointTable.Lap = Comp_HeatNumber OR CupPointTable.Lap IS NULL))
		WHERE 
			Cup.Parent_ID = %option:cup_id% AND
			Comp_State = 4
	) AS NumFinishedComps
FROM
	Cup
WHERE
	ID = %option:cup_id%
