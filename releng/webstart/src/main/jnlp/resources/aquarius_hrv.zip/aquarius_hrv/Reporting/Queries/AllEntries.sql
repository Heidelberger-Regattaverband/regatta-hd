SELECT 
	Entry_ID,
	Entry_Race_ID_FK,
	Entry_OwnerClub_ID_FK,
	Entry_Event_ID_FK,
	Entry_Bib,
	TRIM(ISNULL(Entry_BibPrefix, ' ') + CAST(Entry_BIB AS VARCHAR)) AS Entry_FullBib,
	Entry_BoatNumber,
	Entry_Comment,
	Entry_GroupValue,
	Entry_CancelValue,
	Entry_ExternID,
	Entry_Note,
	CAST(Entry_IsLate AS INT) Entry_IsLate,
	Nation_IOC_Code
FROM
	Entry
	LEFT JOIN Club ON Club_ID = Entry_OwnerClub_ID_FK
	LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
WHERE
	Entry_Event_ID_FK = %event%
ORDER BY
	Entry_Race_ID_FK,
	Entry_Bib,
	Entry_GroupValue	
