UPDATE
	AgeClass
SET
	AgeClass_NumSubClasses = 12 -- M
WHERE
	AgeClass_Abbr IN ('MM', 'MW', 'MM/W', 'MW/M')
