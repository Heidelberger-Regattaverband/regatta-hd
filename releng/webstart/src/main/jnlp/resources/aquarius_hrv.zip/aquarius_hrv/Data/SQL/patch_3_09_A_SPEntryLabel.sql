ALTER PROCEDURE UpdateEntryLabels
	@Entry INT,
	@TeamPrefix VARCHAR(8)
AS

--- variables

DECLARE @short VARCHAR(255)
DECLARE @long VARCHAR(512)

DECLARE @count TINYINT
DECLARE @club_id INT
DECLARE @club_short VARCHAR(255)
DECLARE @club_long VARCHAR(512)

DECLARE @owner_id INT
DECLARE @owner_short VARCHAR(255)
DECLARE @owner_long VARCHAR(512)

--- fetch owner club data

SET @owner_id = (SELECT Entry_OwnerClub_ID_FK FROM Entry WHERE Entry_ID = @Entry)
SET @owner_short = (SELECT Club_Abbr FROM Club WHERE Club_ID = @owner_id)
SET @owner_long = (SELECT Club_Name FROM Club WHERE Club_ID = @owner_id)

--- iterate over cursor

DECLARE name_cursor CURSOR FOR 
	SELECT 
		DISTINCT(Club_ID),
		Club_Abbr,
		Club_Name
	FROM
		Crew
		LEFT JOIN Athlet ON Crew_Athlete_ID_FK = Athlet_ID
		LEFT JOIN Club ON Athlet_Club_ID_FK = Club_ID
	WHERE 
		Crew_Entry_ID_FK = @Entry 

--- generate names from table data

OPEN name_cursor

SET @long = ''
SET @short = ''
SET @count = 0

FETCH NEXT FROM name_cursor INTO @club_id, @club_short, @club_long
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @count = @count + 1
	IF @club_id = @owner_id 
	BEGIN
		SET @long = @club_long + '$' + @long
		SET @short = @club_short + '$' + @short
	END	ELSE
	BEGIN
		SET @long = @long + @club_long + '$' 
		SET @short = @short + @club_short + '$'
	END
	FETCH NEXT FROM name_cursor INTO @club_id, @club_short, @club_long
END

SET @short = RTRIM(REPLACE(REPLACE(REPLACE(@short + '!', '$!', ''), '!', ''), '$', ' / '))
SET @long = RTRIM(REPLACE(REPLACE(REPLACE(@long + '!', '$!', ''), '!', ''), '$', ' / '))

IF LEN(@long) = 0
BEGIN
  SET @long = @owner_long
  SET @short = @owner_short
END

IF @count > 1 
BEGIN
  SET @long = @TeamPrefix + ' ' + @long
  SET @short = @TeamPrefix + ' ' + @short
END

CLOSE name_cursor
DEALLOCATE name_cursor

UPDATE 
	Entry
SET
	Entry_LongLabel = @long,
	Entry_ShortLabel = @short,
	Entry_IsTeam = CASE WHEN @count < 2 THEN 0 ELSE 1 END
WHERE
	Entry_ID = @Entry
