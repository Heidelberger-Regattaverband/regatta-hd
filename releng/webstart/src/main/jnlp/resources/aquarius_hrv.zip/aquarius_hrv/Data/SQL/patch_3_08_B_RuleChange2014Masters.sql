--- change column type for comp's datetime to DATETIME to store seconds

UPDATE
	AgeClass
SET
	AgeClass_NumSubClasses = 11
WHERE
	AgeClass_NumSubClasses > 8

--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.8'
WHERE
	MetaData_Key = 'PatchLevel'