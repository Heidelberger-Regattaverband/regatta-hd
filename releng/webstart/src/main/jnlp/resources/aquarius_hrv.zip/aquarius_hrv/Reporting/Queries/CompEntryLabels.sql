SELECT
    EL_Entry_ID_FK,
    EL_Label_ID_FK,
    EL_RoundFrom,
    EL_RoundTo,
    CAST(EL_IsCrewClubMultiNOC AS INT) AS EL_IsCrewClubMultiNOC,
    CAST(EL_IsClubMultiNOC AS INT) AS EL_IsClubMultiNOC
FROM
    CompEntries
    JOIN Comp ON Comp_ID = CE_Comp_ID_FK
    JOIN EntryLabel ON EL_Entry_ID_FK = CE_Entry_ID_FK
        AND EL_RoundFrom <= Comp_Round AND EL_RoundTo >= Comp_Round
WHERE
    CE_Comp_ID_FK = %comp%