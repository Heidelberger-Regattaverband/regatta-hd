SELECT 
	c1.Crew_Club_ID_FK AS Club_ID,
	RANK() OVER (ORDER BY SUM(ISNULL(CupPointTable.Points / BoatClass_NumRowers,0)) DESC) AS CupRank,
	Club_Abbr,
	REPLACE(SUM(ISNULL(CupPointTable.Points / BoatClass_NumRowers,0)), ',', '.') AS Points
FROM
	--- it's a race through the database structure back and forth
	Result
	JOIN CompEntries Startlist ON Startlist.CE_ID = Result.Result_CE_ID_FK
	JOIN Comp ON Comp_ID = Startlist.CE_Comp_ID_FK
	-- fetch latest crew
	INNER JOIN Crew c1 ON c1.Crew_Entry_ID_FK = Startlist.CE_Entry_ID_FK
		AND Crew_RoundFrom <= Comp_Round AND Crew_RoundTo >= Comp_Round
	-- for filtering out teams
	--JOIN EntryLabel ON EL_Entry_ID_FK = Startlist.CE_Entry_ID_FK
	--JOIN Label ON Label_ID = EL_Label_ID_FK
	INNER JOIN Cup ON Comp_Race_ID_FK = Cup.Race_ID_FK AND Cup.Parent_ID = %option:cup_id%
	INNER JOIN CupPointTable ON CupPointTable.Parent_ID = Cup.PointTable_ID_FK AND 
		Result_Rank = CupPointTable.Rank AND 
		Comp_Round = CupPointTable.Round AND
		(Comp_HeatNumber = CupPointTable.Lap OR CupPointTable.Lap IS NULL)
	LEFT JOIN Offer ON Offer_ID = Comp_Race_ID_FK
	LEFT JOIN BoatClass ON BoatClass_ID = Offer_BoatClass_ID_FK
	LEFT JOIN Club ON Club_ID = c1.Crew_Club_ID_FK
WHERE
	-- consider... only official results
	Comp_State = 4 AND
	-- ... only results on the finish line
	Result_SplitNr = 64 AND
	-- ... only 'ordinary' results, no IRMs
	Result.Result_ResultType = 'N' AND
	-- ... and no coxes
	Crew_IsCox = 0
	--- filter out team crews if desired
	--AND Label_IsTeam = 0
GROUP BY
	c1.Crew_Club_ID_FK,
	Club_Abbr
ORDER BY
	CupRank ASC
