-- Remove old columns from entry table
-- Do that fucking mess to get rid of the default constraint, first.
DECLARE @constraint_name NVARCHAR(256)

SELECT
	@constraint_name = constr.name
FROM
	sys.tables tbls
	JOIN sys.default_constraints constr ON constr.parent_object_id = tbls.object_id
	JOIN sys.columns cols ON cols.object_id = tbls.object_id AND cols.column_id = constr.parent_column_id
WHERE
	tbls.name = 'Entry' AND cols.name = 'Entry_IsTeam'

EXEC(N'ALTER TABLE Entry DROP CONSTRAINT ' + @constraint_name)

-- actual column drop
ALTER TABLE
	Entry
DROP COLUMN
	Entry_LongLabel,
	Entry_ShortLabel,
	Entry_IsTeam