--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.20'
WHERE
	MetaData_Key = 'PatchLevel'
