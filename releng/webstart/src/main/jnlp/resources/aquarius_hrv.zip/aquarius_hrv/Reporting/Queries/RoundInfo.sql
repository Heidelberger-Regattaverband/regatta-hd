SELECT DISTINCT TOP 1
	Comp_Round AS RoundInfo_Number,
	Comp_RoundCode AS RoundInfo_Code,
	ISNULL(Comp_Distance, Offer_Distance) AS Round_Distance
FROM
	Comp JOIN Offer ON Offer_ID = Comp_Race_ID_FK
WHERE
	Comp_Race_ID_FK = %race%
	AND Comp_Round = %round%