-- default values for cox limits
UPDATE AgeClass SET AgeClass_LW_CoxLowerLimit = 0 WHERE AgeClass_LW_CoxLowerLimit IS NULL
UPDATE AgeClass SET AgeClass_LW_CoxTolerance = 0 WHERE AgeClass_LW_CoxTolerance IS NULL
UPDATE AgeClass SET AgeClass_LW_UpperLimit = 0 WHERE AgeClass_LW_UpperLimit IS NULL
UPDATE AgeClass SET AgeClass_LW_AvgLimit = 0 WHERE AgeClass_LW_AvgLimit IS NULL

ALTER TABLE AgeClass ALTER COLUMN AgeClass_LW_CoxLowerLimit INT NOT NULL
ALTER TABLE AgeClass ALTER COLUMN AgeClass_LW_CoxTolerance INT NOT NULL
ALTER TABLE AgeClass ALTER COLUMN AgeClass_LW_UpperLimit INT NOT NULL
ALTER TABLE AgeClass ALTER COLUMN AgeClass_LW_AvgLimit INT NOT NULL

ALTER TABLE AgeClass ADD
	/* The default scope is day (Offered Race (O) for FISA and event (E) for per-regatta). */
	AgeClass_LW_WeighinScope CHAR(1) NOT NULL DEFAULT ('D'),
	AgeClass_Cox_WeighinScope CHAR(1) NOT NULL DEFAULT ('D')
GO

-- new default weigh scopes
UPDATE AgeClass SET AgeClass_LW_WeighinScope = 'E' WHERE (AgeClass_Abbr LIKE 'Jung%') OR (AgeClass_Abbr LIKE 'M�d%') -- event-scope weighin for child lightweights
UPDATE AgeClass SET AgeClass_Cox_WeighinScope = '-' WHERE (AgeClass_Abbr LIKE 'Jung%') OR (AgeClass_Abbr LIKE 'M�d%') -- no weighin for coxes in child races
GO

/* Simple log of all weigh-in data. Records when which person had which weight. Note, this is GDP-relevant. */
CREATE TABLE WeighinLog (
	WL_ID INT IDENTITY(1,1) NOT NULL,
	WL_Athlete_ID_FK INT NOT NULL,
	WL_ScopeRace_ID_FK INT NULL, -- The race is required here for FISA races, where athletes may appear multiple times per day for different offered events.
	WL_Weight INT NOT NULL DEFAULT (0),
	WL_DateTime DATETIME NOT NULL,
	CONSTRAINT PK_WeighinLog PRIMARY KEY CLUSTERED ( WL_ID ),
	CONSTRAINT FK_WeighinLog_Athlete FOREIGN KEY([WL_Athlete_ID_FK]) REFERENCES Athlet (Athlet_ID) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT FK_WeighinLog_Race FOREIGN KEY([WL_ScopeRace_ID_FK]) REFERENCES Offer (Offer_ID) ON UPDATE CASCADE ON DELETE SET NULL,
	INDEX IDX_Date (WL_DateTime),
	INDEX IDX_Athlete (WL_Athlete_ID_FK),
	INDEX IDX_Race (WL_ScopeRace_ID_FK)
)
GO

CREATE TABLE WeighinCrew (
	WC_ID INT IDENTITY(1,1) NOT NULL,
	WC_Entry_ID_FK INT NOT NULL,
	WC_Log_ID_FK INT NOT NULL,
	WC_RoundScope INT DEFAULT (64),
	WC_IsForCox BIT NOT NULL DEFAULT (0),
	WC_WeighDelta INTEGER NOT NULL DEFAULT (0),
	WC_State TINYINT NOT NULL DEFAULT (0),
	WC_Source CHAR(1) NOT NULL DEFAULT ('X'),
	CONSTRAINT PK_WeighinCrew PRIMARY KEY CLUSTERED ( WC_ID ),
	CONSTRAINT FK_WeighinCrew_Entry FOREIGN KEY([WC_Entry_ID_FK]) REFERENCES Entry (Entry_ID) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT FK_WeighinCrew_Log FOREIGN KEY([WC_Log_ID_FK]) REFERENCES WeighinLog (WL_ID) ON UPDATE CASCADE ON DELETE CASCADE,
	INDEX IDX_Entry (WC_Entry_ID_FK),
	INDEX IDX_Log (WC_Log_ID_FK),
	INDEX IDX_Round (WC_RoundScope)
)
GO

/* Weigh-in state of an entry. */
CREATE TABLE WeighinState (
	WS_ID INT IDENTITY(1,1) NOT NULL,
	WS_Entry_ID_FK INT NOT NULL,
	WS_Round SMALLINT NOT NULL DEFAULT (64),
	WS_State TINYINT NOT NULL DEFAULT(0), -- Bitmask of the weigh state
	WS_IsLocked BIT NOT NULL DEFAULT (0), -- If a state is locked, it will not be updated anymore which allows to delete data from the log.
	WS_DeadWeight INT NOT NULL DEFAULT (0)
	CONSTRAINT PK_WeighinState PRIMARY KEY CLUSTERED ( WS_ID ),
	CONSTRAINT FK_WeighinState_Entry FOREIGN KEY([WS_Entry_ID_FK]) REFERENCES [Entry] (Entry_ID) ON UPDATE CASCADE ON DELETE CASCADE
)
GO
