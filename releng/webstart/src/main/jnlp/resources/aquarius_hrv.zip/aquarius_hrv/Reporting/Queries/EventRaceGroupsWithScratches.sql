SELECT 
	Entry_Race_ID_FK AS Race_ID,
	CAST (Entry_GroupValue AS INT) AS GroupValue,
	Offer_GroupMode AS Mode,
	Entry_GroupValue % 4 AS PerfGroup,
	(Entry_GroupValue / 4) AS AgeGroup,
	COUNT(Entry_ID) - SUM(CAST (CAST (Entry_CancelValue AS BIT) AS INT)) AS Remainders,
	COUNT(Entry_ID) AS Entries,
	COUNT(DISTINCT(Label_Short)) AS Clubs,
	MAX(CAST(Offer_ForceDriven AS INT)) AS ForceDriven
FROM 
	Entry
	LEFT JOIN Offer ON Entry_Race_ID_FK = Offer_ID
	JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID AND EL_RoundFrom = 0
	JOIN Label ON Label_ID = EL_Label_ID_FK
WHERE
	Entry_Event_ID_FK = %EVENT%
GROUP BY
	Entry_Race_ID_FK,
	Entry_GroupValue,
	Offer_GroupMode
ORDER BY
	Entry_GroupValue
